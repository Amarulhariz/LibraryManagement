<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Account</title>
    <link rel="stylesheet" href="Create.css">
</head>
<body>

<div class="container">
    <div class="left-half">
        <div class="logo">
            <img src="gambar/MAHA1.png" alt="Logo">
        </div>
        <div class="login-container">
            <h2>Create Account</h2>
            <form action="includes/signup.inc.php" method="post">
            <div class="input-box">
                    <input type="text" id="StudentID" name="StudentID" placeholder="Student ID" required>
                </div>
                <div class="input-box">
                    <input type="text" id="StudentName" name="StudentName"placeholder="Name" required>
                </div>

                <div class="input-box">
                    <input type="email" id="StudentAddress" name="StudentAddress"placeholder="Email" required>
                </div>
                <div class="input-box">
                    <input type="tel" id="StudentPhoneNum" name="StudentPhoneNum"placeholder="Phone Number" required>
                </div>

                <div class="input-box">
                    <input type="password" id="password" name="password" placeholder="Password" required>
                </div>

                <div class="input-box">
                    <input type="password" id="Rpassword" name="Rpassword" placeholder="Repeat Password" required>
                </div>

                <button type="submit" name="submit">Sign Up</button>
                <div class="login-con">
                <h3>     OR     </h3>
                </div>
                <button onclick="goToStaffSignUp()">Signup as Staff</button>
            </form>
        <?php
        if (isset($_GET["error"])) {
            if ($_GET["error"] == "emptyinput") {
                echo "<p>Fill in all fields!</p>";
            }elseif ($_GET["error"] == "invalidID") {
                echo "<p>Choose a proper ID!</p>";
            }elseif ($_GET["error"] == "invalidname") {
                echo "<p>Choose a proper username!</p>";
            } elseif ($_GET["error"] == "invalidemail") {
                echo "<p>Choose a proper Email!</p>";
            } elseif ($_GET["error"] == "invalidphonenumber") {
                echo "<p>Choose another PhoneNumber!</p>";
            } elseif ($_GET["error"] == "passworddontmatch") {
                echo "<p>Passwords don't match!</p>";
            } elseif ($_GET["error"] == "stmtfailed") {
                echo "<p>Something went wrong, try again!</p>";
            } elseif ($_GET["error"] == "usernameexists") {
                echo "<p>Choose another username!</p>";
            } elseif ($_GET["error"] == "none") {
                echo "<p>You have signed up!</p>";
            }
        }
        ?>
 </div>
    </div>

    <div class="right-half">
        <img src="gambar/book.png" alt="Books">
    </div>
</div>
<script>
    function goToStaffSignUp() {
        window.location.href = 'CreateAccStaff.php';
    }
</script>
</body>
</html>




