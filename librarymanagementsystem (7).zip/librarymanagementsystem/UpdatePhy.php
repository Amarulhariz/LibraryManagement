<?php
    session_start();
    include 'includes/dbh.inc.php'; // Include your database connection file

    // Check if book_code is set and not empty
    if (isset($_POST['book_code']) && !empty($_POST['book_code'])) {
        $book_code = mysqli_real_escape_string($conn, $_POST['book_code']);

        // Fetch details of the selected book
        $sql = "SELECT b.Book_Code, b.Book_Name, b.Book_Author, b.Book_Genre, p.BookShelf_ID, p.PBookCode_Status
                FROM books b
                JOIN physicalbook p ON p.Book_Code = b.Book_Code
                WHERE b.Book_Code = '$book_code'";
        
        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);

            // Display the selected book details in a form for updating
            echo '<div class="container">';
            echo '<h1>Update Physical Book</h1>';
            echo '<form action="" method="post" class="update-form">';
            echo '<input type="hidden" name="book_code" value="' . $row['Book_Code'] . '">';
            echo '<table class="update-table">';
            echo '<tr><th>Book Code</th><th>Book Name</th><th>BookShelf ID</th><th>Physical Book Code Status</th></tr>';
            echo '<tr>';
            echo '<td>' . $row['Book_Code'] . '</td>';
            echo '<td>' . $row['Book_Name'] . '</td>';
            echo '<td><input type="text" name="BookShelf_ID" value="' . $row['BookShelf_ID'] . '"></td>';
            echo '<td><input type="text" name="PBookCode_Status" value="' . $row['PBookCode_Status'] . '"></td>';
            echo '</tr>';
            echo '</table>';
            echo '<button type="submit" name="update_submit" class="update-button">Update Book</button>';
            echo '</form>';
            echo '</div>';
        } else {
            echo "<p>No book found with the selected code.</p>";
        }
    } else {
        echo "<p>No book selected for update.</p>";
    }

    if (isset($_POST['update_submit'])) {
        // Retrieve and sanitize inputs
        $book_code = mysqli_real_escape_string($conn, $_POST['book_code']);
        $bookshelf_id = mysqli_real_escape_string($conn, $_POST['BookShelf_ID']);
        $pbookcode_status = mysqli_real_escape_string($conn, $_POST['PBookCode_Status']);

        // Update query for physical book
        $update_query = "UPDATE physicalbook SET BookShelf_ID = '$bookshelf_id', PBookCode_Status = '$pbookcode_status' WHERE Book_Code = '$book_code'";
        
        if (mysqli_query($conn, $update_query)) {
            echo '<div class="container">';
            echo '<h1>Update Successful</h1>';
            echo '<p>Physical book details updated successfully.</p>';
            echo '</div>';
        } else {
            echo '<div class="container">';
            echo '<h1>Error</h1>';
            echo '<p>Failed to update physical book details: ' . mysqli_error($conn) . '</p>';
            echo '</div>';
        }
    }
    
    // Close connection
    mysqli_close($conn);

    include 'footer.php'; 
?>

<style>
    .container {
        width: 80%;
        margin: 0 auto;
        padding: 20px;
        background-color: #f9f9f9;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    h1 {
        text-align: center;
        color: #333;
    }

    .update-form {
        display: flex;
        flex-direction: column;
        align-items: center;
    }

    .update-table {
        width: 100%;
        margin-bottom: 20px;
        border-collapse: collapse;
    }

    .update-table th, .update-table td {
        padding: 10px;
        border: 1px solid #ddd;
        text-align: left;
    }

    .update-table th {
        background-color: #f2f2f2;
    }

    .update-button {
        padding: 10px 20px;
        background-color: #4CAF50;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-size: 16px;
    }

    .update-button:hover {
        background-color: #45a049;
    }

    p {
        text-align: center;
        color: #555;
    }
</style>
