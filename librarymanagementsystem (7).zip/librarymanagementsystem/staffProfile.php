<?php
// update_profile.php

$servername = "localhost";
$username = "your_username";
$password = "your_password";
$dbname = "librarymanagement";

// Create connection
$conn = new mysqli($servername, $username, $password, $librarymanagement);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve form data
$id = $_POST['staff_id']; // Example: S12345
$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];

// Update query
$sql = "UPDATE your_table SET Staff_Name='$name', staffEmail='$email', StaffPhone_Num='$phone' WHERE Staff_ID='$id'";

if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully";
} else {
    echo "Error updating record: " . $conn->error;
}

$conn->close();
?>
