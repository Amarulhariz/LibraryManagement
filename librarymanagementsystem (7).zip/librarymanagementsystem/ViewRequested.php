<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Page</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            padding: 20px;
        }
        .container {
            max-width: 1000px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        h1 {
            text-align: left;
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #4CAF50;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        tr:hover {
            background-color: #ddd;
        }
        .request-button {
            padding: 10px 20px;
            font-size: 16px;
            border: none;
            border-radius: 4px;
            background-color: #4CAF50;
            color: white;
            cursor: pointer;
            margin-top: 20px;
            display: block;
            text-align: center;
            width: 100px;
            margin: 20px auto;
        }
        .request-button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <?php
    session_start();
    include 'includes/dbh.inc.php'; // Include your database connection file

    // Check if the form was submitted
    if(isset($_POST['bookNameS']) && !empty($_POST['bookNameS'])) {
        // prevent sql injection
        $search = mysqli_real_escape_string($conn, $_POST['bookNameS']);

        // basic sql
        $sql = "SELECT b.Book_Code, b.Book_Name, b.Book_Author, b.Book_Genre, p.PBookCode_Status, e.EBookCode_Status
                FROM books b
                JOIN physicalbook p ON p.Book_Code = b.Book_Code
                JOIN ebook e ON e.Book_Code = b.Book_Code
                WHERE (b.Book_Name LIKE '%$search%' OR b.Book_Author LIKE '%$search%' OR b.Book_Genre LIKE '%$search%') AND e.EBookCode_Status LIKE 'available'";
        // Execute the query
        $result = mysqli_query($conn, $sql);

        // Check if any results were found
        $queryResult = mysqli_num_rows($result);

        if ($queryResult > 0) {
            // Output the results in a table
            echo '<div class="container">';
            echo '<h1>Search Results</h1>';
            echo '<form id="requestForm" action="" method="post">'; // Action points to the same page
            echo '<table>';
            echo '<tr><th>Select</th><th>Code</th><th>Name</th><th>Author</th><th>Genre</th><th>E-Book Status</th></tr>';

            // Loop through each row in the result set and display the data
            while($row = mysqli_fetch_assoc($result)) {
                echo '<tr>';
                echo '<td><input type="checkbox" name="selected_books[]" value="' . $row["Book_Code"] . '"></td>';
                echo "<td>" . $row["Book_Code"] . "</td>";
                echo "<td>" . $row["Book_Name"] . "</td>";
                echo "<td>" . $row["Book_Author"] . "</td>";
                echo "<td>" . $row["Book_Genre"] . "</td>";
                echo "<td>" . $row["EBookCode_Status"] . "</td>";
                echo '</tr>';
            }

            echo '</table>';
            echo '<button type="submit" name="request_submit" class="request-button">Request</button>';
            echo '</form>';
            echo '</div>';
        } else {
            echo "<div class='container'>";
            echo "No Book matching '$search'";
            echo "</div>";
        }
    }

    if (isset($_SESSION["Student_ID"])) {
        $student = $_SESSION["Student_ID"];
    }

    // Handle form submission for book request
    if (isset($_POST['request_submit'])) {
        // Ensure selected_books is set
        if (isset($_POST['selected_books'])) {
            $selected_books = $_POST['selected_books'];

            // Insert selected books into the database
            foreach ($selected_books as $book_code) {
                $book_code = mysqli_real_escape_string($conn, $book_code);

                // Example insertion query, adjust table and fields as per your database schema
                $insert_query = "INSERT INTO request (Book_Code,Student_ID,Requested_Status) VALUES ('$book_code','$student','pending')";
                mysqli_query($conn, $insert_query); // Execute query
            }

            echo "Selected books successfully requested.";
        } else {
            echo "No books selected for request.";
        }
    }
    ?>
    
    <?php include 'footer.php'; ?>
    <div class="reference" onclick="toggleMenu()">
    <span></span>
    <span></span>
    <span></span>
</div>

<div id="sideMenu" class="sidebar">
    <button class="close-btn" onclick="toggleMenu()">&times;</button> <!-- Close Button -->
    <img src="gambar/MAHA1.png" alt="Profile Picture">
    <a href="mainMenu.php">Main Menu</a>
    <a href="searchBook.php">Search Book</a>
    <a href="RequestPhysical.php">Request Physical Books</a>
    <a href="#">Issue / Return</a>
    <a href="#">Accounts</a>
    <a href="#">Communication</a>
    <a href="#">Reports</a>
</div>

<div class="overlay" onclick="toggleMenu()"></div>
<script>
function toggleMenu() {
    const reference = document.querySelector('.reference');
    const sidebar = document.getElementById('sideMenu');
    const overlay = document.getElementById('overlay');

    reference.classList.toggle('toggle');
    sidebar.classList.toggle('show');
    overlay.classList.toggle('show');
}

// Initialize the overlay click event
document.addEventListener('DOMContentLoaded', function () {
    const overlay = document.getElementById('overlay');
    overlay.addEventListener('click', toggleMenu);
});

</script>
<script src="script.js"></script>
</body>
</html>
