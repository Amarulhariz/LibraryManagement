<?php
session_start();
include 'includes/dbh.inc.php';

// Check if the staff is logged in
if (isset($_SESSION['Staff_ID'])) {
    $staff = $_SESSION['Staff_ID'];
    
    // Fetch user data from the database
    $sql = "SELECT * FROM staff WHERE Staff_ID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $staff);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    
    if (!$user) {
        // Handle if staff data is not found
        header("Location: error.php");
        exit();
    }
} else {
    // Redirect to login if not logged in
    header("Location: login.php");
    exit();
}

// Handle form submission
$message = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
    $UserName = $_POST['UserName'];
    $UserPhoneNum = $_POST['UserPhoneNum'];
    $UserEmail = $_POST['UserEmail'];
    $UserPassword = $_POST['UserPassword'];

    // File upload handling
    $profilePicture = $_FILES['profilePicture'];

    // Check if a new file has been uploaded
    if ($profilePicture['error'] == UPLOAD_ERR_OK) {
        // Process the uploaded file
        $uploadDir = 'gambar/'; // Directory where images will be uploaded
        $uploadFile = $uploadDir . basename($profilePicture['name']);

        if (move_uploaded_file($profilePicture['tmp_name'], $uploadFile)) {
            // Update database with new profile picture filename
            $sql = "UPDATE staff SET Staff_Name = ?, StaffPhone_Num = ?, StaffEmail = ?, StaffImg = ? WHERE Staff_ID = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssssi", $UserName, $UserPhoneNum, $UserEmail, $uploadFile, $staff);
        } else {
            $message = "Error uploading profile picture.";
        }
    } else {
        // Update user data without changing profile picture
        if (empty($UserPassword)) {
            $sql = "UPDATE staff SET Staff_Name = ?, StaffPhone_Num = ?, StaffEmail = ? WHERE Staff_ID = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sssi", $UserName, $UserPhoneNum, $UserEmail, $staff);
        } else {
            $hashedPassword = password_hash($UserPassword, PASSWORD_DEFAULT);
            $sql = "UPDATE staff SET Staff_Name = ?, StaffPhone_Num = ?, StaffEmail = ?, StaffPwd = ? WHERE Staff_ID = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssssi", $UserName, $UserPhoneNum, $UserEmail, $hashedPassword, $staff);
        }
    }

    if ($stmt->execute()) {
        $message = "Profile updated successfully.";
    } else {
        $message = "Error updating profile.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="EditStaff.css">
    <title>Edit Personal Details</title>
</head>
<body>
    <div class="sidebar">
        <img src="<?php echo htmlspecialchars($user['StaffImg'] ?? 'gambar/amarul.jpg'); ?>" alt="Profile Picture" class="profile-picture">
        <h1>Welcome, <?php echo htmlspecialchars($user['Staff_Name'] ?? 'Staff'); ?></h1>
        <div class="sidebar_title">
            <a href="mainMenu.php">HOME</a>
            <a href="ProfileStaff.php">STAFF PROFILE</a>
            <a href="EditStaff.php">EDIT PROFILE</a>
            <a href="includes/logout.inc.php">LOG OUT</a>
        </div>
    </div>
    
    <div class="content">
        <h1>Edit Staff Details</h1>
        <div class="box">
            <form action="EditStaff.php" method="post" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="UserName">Name:</label>
                    <input type="text" id="UserName" name="UserName" value="<?php echo htmlspecialchars($user['Staff_Name']); ?>">
                </div>
                <div class="form-group">
                    <label for="UserPhoneNum">Phone Number:</label>
                    <input type="text" id="UserPhoneNum" name="UserPhoneNum" value="<?php echo htmlspecialchars($user['StaffPhone_Num']); ?>">
                </div>
                <div class="form-group">
                    <label for="UserEmail">Email Address:</label>
                    <input type="email" id="UserEmail" name="UserEmail" value="<?php echo htmlspecialchars($user['StaffEmail']); ?>">
                </div>
                <div class="form-group">
                    <label for="UserPassword">New Password:</label>
                    <input type="password" id="UserPassword" name="UserPassword" placeholder="Leave blank to keep current">
                </div>
                <div class="form-group">
                    <label for="profilePicture">Profile Picture:</label>
                    <input type="file" id="profilePicture" name="profilePicture">
                </div>
                <button type="submit" name="submit">Submit</button>
                <div id="update-message"><?php echo htmlspecialchars($message); ?></div>
            </form>
        </div>
    </div>
</body>
</html>
