<?php
    // Include the database connection
    include '../includes/dbh.inc.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Result: Romance Book</title>
    <link rel="stylesheet" href="booktype.css">
    <link rel="stylesheet" href="../SideBar.css">
</head>
<body>
    <div class="container">
        <h1>Search Result: Romance Book</h1>
        <table>
            <tr>
                <th>Book ID</th>
                <th>Book Name</th>
                <th>Book Author</th>
                <th>Book Genre</th>
                <th>Physical Book</th>
                <th>EBook</th>
            </tr>
            <?php
            // Fetch data from the database
            $sql = "SELECT b.Book_Code, b.Book_Name, b.Book_Author, b.Book_Genre, p.PBookCode_Status, e.EBookCode_Status
                    FROM books b
                    JOIN physicalbook p ON p.Book_Code = b.Book_Code
                    JOIN ebook e ON e.Book_Code = b.Book_Code
                    WHERE b.Book_Genre LIKE '%Romance%'";
            $result = mysqli_query($conn, $sql);

            // Check if there are results
            if (mysqli_num_rows($result) > 0) {
                // Output data of each row
                while($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td>" . $row["Book_Code"] . "</td>";
                    echo "<td>" . $row["Book_Name"] . "</td>";
                    echo "<td>" . $row["Book_Author"] . "</td>";
                    echo "<td>" . $row["Book_Genre"] . "</td>";
                    echo "<td>" . $row["PBookCode_Status"] . "</td>";
                    echo "<td>" . $row["EBookCode_Status"] . "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='6'>No results found</td></tr>";
            }

            // Close the database connection
            $conn->close();
            ?>
        </table>
    </div>
    <div class="reference" onclick="toggleMenu()">
    <span></span>
    <span></span>
    <span></span>
</div>

<div id="sideMenu" class="sidebar">
    <button class="close-btn" onclick="toggleMenu()">&times;</button> <!-- Close Button -->
    <img src="../gambar/MAHA1.png" alt="Profile Picture">
    <a href="../mainMenu.php">Main Menu</a>
    <a href="../searchBook.php">Search Book</a>
    <a href="../RequestPhysical.php">Request Physical Books</a>
    <a href='../RequestEbook.php'>Request EBook</a>
    <a href='../viewRequestPhysical.php'>View Request Physical Books</a>
    <a href='../viewRequestEbook.php'>View Request EBooks</a>
</div>

<div class="overlay" onclick="toggleMenu()"></div>

<script>
function toggleMenu() {
    const reference = document.querySelector('.reference');
    const sidebar = document.getElementById('sideMenu');
    const overlay = document.querySelector('.overlay');

    reference.classList.toggle('toggle');
    sidebar.classList.toggle('show');
    overlay.classList.toggle('show');
}

// Initialize the overlay click event
document.addEventListener('DOMContentLoaded', function () {
    const overlay = document.querySelector('.overlay');
    overlay.addEventListener('click', toggleMenu);
});
</script>

<script src="script.js"></script>
</body>
</html>

<?php
    // Include the footer
    include_once '../footer.php';
?>
