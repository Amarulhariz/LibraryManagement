<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MAHA Library</title>
    <link rel="stylesheet" href="login.css">
</head>
<body>
    <div class="container">
        <div class="logo">
            <img src="gambar/MAHA1.png" alt="MAHA Library Logo"> 
        </div>
		<div class="title">
            <div class="welcome">WELCOME TO</div>
            <div class="maha">MAHA</div>
            <div class="library">Library</div>
        </div>

        <div class="buttons">
            <a href="loginPage.php">Log In</a>
			<div></div>
            <a href="CreateAccount.php">Sign Up</a>
        </div>
    </div>

	<script>
		function toggleMenu() {
			var menu = document.getElementById("sideMenu");
			var button = document.querySelector(".reference");
			
			if (menu.classList.contains("active")) {
				menu.classList.remove("active");
				button.classList.remove("toggle");
			} else {
				menu.classList.add("active");
				button.classList.add("toggle");
			}
		}
	</script>
	<div class="reference" onclick="toggleMenu()">
		<span></span>
		<span></span>
		<span></span>
	</div>
	<div id="sideMenu" class="side-menu">
	<div>.</div>
	<div>.</div>
	<div><a href ="CreateAccount.php">Sign up page</a></div>
	<div><a href ="LoginPage.php">login page</a></div>
	</div>
</body>
</html>
