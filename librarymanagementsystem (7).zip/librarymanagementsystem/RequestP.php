<?php
    session_start();
    include 'includes/dbh.inc.php'; // Include your database connection file
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Page</title>
    <style>
        /* Resetting body styles and background */
        body {
            font-family: Arial, sans-serif;
            background: url('gambar/background.png') no-repeat center center fixed;
            background-size: cover;
            padding: 20px;
            margin: 0;
            color: #000000; /* Default text color */
        }

        /* Container styles */
        .container {
            max-width: 1000px;
            margin: 50px auto; /* Centering the container */
            background-color: rgba(255, 255, 255, 0.3);
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        /* Heading styles */
        h1 {
            text-align: left;
            color: white; /* Green header text */
            margin-bottom: 20px;
        }

        /* Table styles */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            border-radius: 8px;
            overflow: hidden; /* Prevents borders from showing outside */
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        th, td {
            border: 1px solid #887c7c;
            padding: 12px;
            text-align: left;
        }

        th {
            background-color: #4c6daf; /* Green header background */
            color: white;
        }

        /* Alternate row background color */
        tr:nth-child(even) {
            background-color: #ffffff;
        }
        tr:nth-child(odd) {
            background-color: #f2f2f2;
        }

        /* Request button styling */
        .request-button {
            padding: 10px 20px;
            font-size: 16px;
            border: none;
            border-radius: 4px;
            background-color: #4CAF50;
            color: white;
            cursor: pointer;
            margin-top: 20px;
            display: block;
            text-align: center;
            width: 100px;
            margin: 20px auto;
        }

        .request-button:hover {
            background-color: #45a049;
        }

        /* Sidebar and Overlay styles (assuming they are in SideBar.css) */
        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: 250px;
            height: 100%;
            background-color: #333;
            padding-top: 60px;
            transition: 0.3s;
            z-index: 1000;
            color: #fff; /* White text color */
        }

        .overlay {
            position: fixed;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
            top: 0;
            left: 0;
            z-index: 999;
            display: none;
        }

        /* Responsive toggle menu styles */
        .reference {
            cursor: pointer;
            padding: 10px;
            position: fixed;
            left: 20px;
            top: 20px;
            z-index: 1500;
        }

        .toggle {
            transform: rotate(180deg);
            transition: transform 0.3s ease;
        }

        .show {
            transform: translateX(0);
        }

        .close-btn {
            position: absolute;
            top: 20px;
            right: 20px;
            color: #fff; /* White close button text */
            font-size: 24px;
            cursor: pointer;
        }

        /* Profile picture styling */
        img {
            display: block;
            width: 80px;
            height: auto;
            margin: 0 auto 20px;
            border-radius: 50%;
        }
    </style>
</head>
<body>
    <?php
    // Check if the form was submitted
    if(isset($_POST['bookNameS']) && !empty($_POST['bookNameS'])) {
        // prevent sql injection
        $search = mysqli_real_escape_string($conn, $_POST['bookNameS']);

        // basic sql
        $sql = "SELECT b.Book_Code, b.Book_Name, b.Book_Author, b.Book_Genre, p.PBookCode_Status
                FROM books b
                JOIN physicalbook p ON p.Book_Code = b.Book_Code
                WHERE (b.Book_Name LIKE '%$search%' OR b.Book_Author LIKE '%$search%' OR b.Book_Genre LIKE '%$search%') AND p.PBookCode_Status LIKE 'available'";
        // Execute the query
        $result = mysqli_query($conn, $sql);

        // Check if any results were found
        $queryResult = mysqli_num_rows($result);

        if ($queryResult > 0) {
            // Output the results in a table
            echo '<div class="container">';
            echo '<h1>Search Results</h1>';
            echo '<form id="requestForm" action="" method="post">'; // Action points to the same page
            echo '<table>';
            echo '<tr><th>Select</th><th>Code</th><th>Name</th><th>Author</th><th>Genre</th><th>Physical Book Status</th><th>Pick Up Date</th><th>Pick Up Time</th></tr>';

            // Loop through each row in the result set and display the data
            while($row = mysqli_fetch_assoc($result)) {
                echo '<tr>';
                echo '<td><input type="checkbox" name="selected_books[]" value="' . $row["Book_Code"] . '"></td>';
                echo "<td>" . $row["Book_Code"] . "</td>";
                echo "<td>" . $row["Book_Name"] . "</td>";
                echo "<td>" . $row["Book_Author"] . "</td>";
                echo "<td>" . $row["Book_Genre"] . "</td>";
                echo "<td>" . $row["PBookCode_Status"] . "</td>";
                echo '<td><input type="date" name="pickup_date[' . $row["Book_Code"] . ']" ></td>';
                echo '<td><input type="time" name="pickup_time[' . $row["Book_Code"] . ']" ></td>';
                echo '</tr>';
            }

            echo '</table>';
            echo '<button type="submit" name="request_submit" class="request-button">Request</button>';
            echo '</form>';
            echo '</div>';
        } else {
            echo "<div class='container'>";
            echo "No Book matching '$search'";
            echo "</div>";
        }
    }

    if (isset($_SESSION["Student_ID"])) {
        $student = $_SESSION["Student_ID"];
    }

    // Handle form submission for book request
    if (isset($_POST['request_submit'])) {
        // Ensure selected_books is set
        if (isset($_POST['selected_books'])) {
            $selected_books = $_POST['selected_books'];
    
            foreach ($selected_books as $book_code) {
                // Retrieve pick-up date and time for each book
                $pickup_date = $_POST['pickup_date'][$book_code];
                $pickup_time = $_POST['pickup_time'][$book_code];
    
                // Ensure date and time are not empty
                if (!empty($pickup_date) && !empty($pickup_time)) {
                    $pickup_date = mysqli_real_escape_string($conn, $pickup_date);
                    $pickup_time = mysqli_real_escape_string($conn, $pickup_time);
    
                    // Insert into database with date and time
                    $insert_query = "INSERT INTO requestp (Book_Code, Student_ID, RequestedP_Status, PickUp_Date, PickUp_Time) VALUES ('$book_code', '$student', 'pending', '$pickup_date', '$pickup_time')";
                    mysqli_query($conn, $insert_query); // Execute query
                } else {
                    echo "<script>alert('Please select pick-up date and time for all selected books.');</script>";
                }
            }
    
            echo "<script>
                alert('Selected books successfully requested.');
                window.location.href = 'requestPhysical.php';
            </script>";
        } else {
            echo "<script>alert('No books selected for request.');</script>";
        }
    }
?>
</body>
</html>
