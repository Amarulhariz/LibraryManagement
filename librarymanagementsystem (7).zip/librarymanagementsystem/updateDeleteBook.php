<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="UpdateDelete.css">
    <link rel="stylesheet" href="SideBar.css">
    <title>Manage Books</title>
    
</head>
<body>
    <div class="container">
        <h1>Manage Books</h1>

        <?php
        // Include necessary files
        session_start();
        include 'includes/dbh.inc.php'; // Include your database connection file

        // Prepare SQL statement
        $sql = "SELECT b.Book_Code, b.Book_Name, b.Book_Author, b.Book_Genre, p.PBookCode_Status, e.EBookCode_Status
                FROM books b
                JOIN physicalbook p ON p.Book_Code = b.Book_Code
                JOIN ebook e ON e.Book_Code = b.Book_Code";

        // Execute query
        $result = mysqli_query($conn, $sql);

        // Check if any results were found
        if (mysqli_num_rows($result) > 0) {
            // Output the results in a table
            echo '<table>';
            echo '<tr><th>Code</th><th>Name</th><th>Author</th><th>Genre</th><th>Physical Status</th><th>Action (Physical)</th><th>E-Book Status</th><th>Action (E-Book)</th><th>Action (Book)</th><th>Update Book Details</th></tr>';

            // Loop through each row in the result set and display the data
            while ($row = mysqli_fetch_assoc($result)) {
                echo '<tr>';
                echo "<td>" . $row["Book_Code"] . "</td>";
                echo "<td>" . $row["Book_Name"] . "</td>";
                echo "<td>" . $row["Book_Author"] . "</td>";
                echo "<td>" . $row["Book_Genre"] . "</td>";
                echo "<td>" . $row["PBookCode_Status"] . "</td>";
                echo '<td>';
                echo '<form method="post" action="UpdatePhy.php" style="display: inline;">';
                echo '<input type="hidden" name="book_code" value="' . $row["Book_Code"] . '">';
                echo '<button type="submit" class="btn btn-update">Update</button>';
                echo '</form>';
                echo '</td>';
                echo "<td>" . $row["EBookCode_Status"] . "</td>";
                echo '<td>';
                echo '<form method="post" action="UpdateEbook.php" style="display: inline;">';
                echo '<input type="hidden" name="book_code" value="' . $row["Book_Code"] . '">';
                echo '<button type="submit" class="btn btn-update">Update</button>';
                echo '</form>';
                echo '</td>';
                echo '<td>';
                echo '<form method="post" action="deleteBook.php" style="display: inline;">';
                echo '<input type="hidden" name="book_code" value="' . $row["Book_Code"] . '">';
                echo '<button type="submit" class="btn btn-delete">Delete</button>';
                echo '</form>';
                echo '</td>';
                echo '<td>';
                echo '<form method="post" action="UpdateBookDetails.php" style="display: inline;">';
                echo '<input type="hidden" name="book_code" value="' . $row["Book_Code"] . '">';
                echo '<button type="submit" class="btn btn-update-details">Update Details</button>';
                echo '</form>';
                echo '</td>';
                echo '</tr>';
            }

            echo '</table>';
        } else {
            echo "<p>No books found.</p>";
        }

        // Close connection
        mysqli_close($conn);
        ?>

    </div>

    <?php include 'footer.php'; // Assuming footer.php includes your footer content ?>
    <div class="reference" onclick="toggleMenu()">
        <span></span>
        <span></span>
        <span></span>
    </div>

    <div id="sideMenu" class="sidebar">
        <button class="close-btn" onclick="toggleMenu()">&times;</button> <!-- Close Button -->
        <img src="gambar/MAHA1.png" alt="Profile Picture">
        <a href="mainMenu.php">Main Menu</a>
        <a href='AddBook.php'>Add new Book</a>
        <a href='UpdateDeleteBook.php'>Update and Delete new Book</a>
        <a href='GenerateRecord.php'>Print Borrowing Record</a>
    </div>

    <div class="overlay" onclick="toggleMenu()"></div>
    <script>
    function toggleMenu() {
        const reference = document.querySelector('.reference');
        const sidebar = document.getElementById('sideMenu');
        const overlay = document.getElementById('overlay');

        reference.classList.toggle('toggle');
        sidebar.classList.toggle('show');
        overlay.classList.toggle('show');
    }

    // Initialize the overlay click event
    document.addEventListener('DOMContentLoaded', function () {
        const overlay = document.getElementById('overlay');
        overlay.addEventListener('click', toggleMenu);
    });
    </script>
    <script src="script.js"></script>
</body>
</html>
