<?php
if (isset($_POST["submit"])) {
    $StaffID = $_POST["StaffID"];
    $Staffname = $_POST["StaffName"];
    $Staffemail = $_POST["StaffAddress"];
    $StaffphoneNum = $_POST["StaffPhoneNum"];
    $Staffpassword = $_POST["Staffpassword"];
    $StaffRpassword = $_POST["StaffRpassword"];
    
    require_once 'dbh.inc.php';
    require_once 'functionS.inc.php';

    if (emptyInputSignupS($StaffID ,$Staffname, $Staffemail, $StaffphoneNum, $Staffpassword, $StaffRpassword)) {
        header("Location: ../CreateAccStaff.php?error=emptyinput");
        exit();
    }
    if (invalidIDS($StaffID)) {
        header("Location: ../CreateAccStaff.php?error=invalidID");
        exit();
    }

    if (invalidNameS($Staffname)) {
        header("Location: ../CreateAccStaff.php?error=invalidname");
        exit();
    }

    if (invalidEmailS($Staffemail)) {
        header("Location: ../CreateAccStaff.php?error=invalidemail");
        exit();
    }

    if (pwdMatchS($Staffpassword, $StaffRpassword)) {
        header("Location: ../CreateAccStaff.php?error=passworddontmatch");
        exit();
    }

    if (invalidPhoneNumberS($StaffphoneNum)) {
        header("Location: ../CreateAccStaff.php?error=invalidphonenumber");
        exit();
    }

    if (userNameExistS($conn, $StaffID, $Staffname, $Staffemail, $StaffphoneNum)) {
        header("Location: ../CreateAccStaff.php?error=usernameexists");
        exit();
    }

    createUserS($conn, $StaffID, $Staffname, $Staffemail, $StaffphoneNum, $Staffpassword);
} else {
    header("Location: ../CreateAccStaff.php");
    exit();
}