<?php
if(isset($_POST["submit"])){
    $ID = $_POST["StudentID"];
    $password = $_POST["StudentPwd"];

    require_once 'dbh.inc.php';
    require_once 'function.inc.php';

    if (emptyInputLogin($ID, $password)) {
        header("Location: ../LoginPage.php?error=emptyinput");
        exit();
    }

    loginUser($conn, $ID, $password);
}
else {
    header("location: ../LoginPage.php");
    exit();
}


