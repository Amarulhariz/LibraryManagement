<?php

// Check for empty input in the staff signup form
function emptyInputSignupS($StaffID, $Staffname, $Staffemail, $StaffphoneNum, $Staffpassword, $StaffRpassword) {
    return empty($StaffID) || empty($Staffname) || empty($Staffemail) || empty($StaffphoneNum) || empty($Staffpassword) || empty($StaffRpassword);
}

// Validate staff ID
function invalidIDS($StaffID) {
    return !preg_match("/^[a-zA-Z0-9]*$/", $StaffID);
}

// Validate staff name
function invalidNameS($Staffname) {
    return !preg_match("/^[a-zA-Z0-9]*$/", $Staffname);
}

// Validate staff email
function invalidEmailS($Staffemail) {
    return !filter_var($Staffemail, FILTER_VALIDATE_EMAIL);
}

// Validate staff phone number
function invalidPhoneNumberS($StaffphoneNum) {
    return !preg_match("/^[0-9]*$/", $StaffphoneNum);
}

// Check if passwords match
function pwdMatchS($Staffpassword, $StaffRpassword) {
    return $Staffpassword !== $StaffRpassword;
}

// Check if staff user exists
function userNameExistS($conn, $StaffID, $Staffname, $Staffemail, $StaffphoneNum) {
    $sql = "SELECT * FROM staff WHERE Staff_ID = ? OR Staff_Name = ? OR StaffEmail = ? OR StaffPhone_Num = ?;";
    $stmt = mysqli_stmt_init($conn);
    if (!mysqli_stmt_prepare($stmt, $sql)) {
        header("Location: ../CreateAccStaff.php?error=stmtfailed");
        exit();
    }

    mysqli_stmt_bind_param($stmt, "ssss", $StaffID, $Staffname, $Staffemail, $StaffphoneNum);
    mysqli_stmt_execute($stmt);
    $resultData = mysqli_stmt_get_result($stmt);

    if ($row = mysqli_fetch_assoc($resultData)) {
        // Debug output for fetched data
        echo "Fetched User Data: " . print_r($row, true) . "<br>";
        mysqli_stmt_close($stmt);
        return $row;
    } else {
        mysqli_stmt_close($stmt);
        return false;
    }
}


// Create a new staff user
function createUserS($conn, $StaffID, $Staffname, $Staffemail, $StaffphoneNum, $Staffpassword) {
    $sql = "INSERT INTO staff (Staff_ID, Staff_Name, StaffEmail, StaffPhone_Num, StaffPwd) VALUES (?, ?, ?, ?, ?);";
    $stmt = mysqli_stmt_init($conn);
    if (!mysqli_stmt_prepare($stmt, $sql)) {
        header("Location: ../CreateAccStaff.php?error=stmtfailed");
        exit();
    }

    $hashedPwd = password_hash($Staffpassword, PASSWORD_DEFAULT);
    // Debug output for hashed password
    echo "Hashed Password: " . $hashedPwd . "<br>";
    mysqli_stmt_bind_param($stmt, "sssss", $StaffID, $Staffname, $Staffemail, $StaffphoneNum, $hashedPwd);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    header("Location: ../CreateAccStaff.php?error=none");
    exit();
}


// Check for empty input in the staff login form
function emptyInputLoginS($StaffID, $Staffpassword) {
    return empty($StaffID) || empty($Staffpassword);
}

// Log in a staff user
function loginUserS($conn, $StaffID, $Staffpassword) {
    // Check if the staff user exists
    $StaffData = userNameExistS($conn, $StaffID, '', '', '');

    if ($StaffData === false) {
        header("Location: ../LoginPageS.php?error=wronglogin");
        exit();
    }

    // Retrieve the hashed password from the user data
    $hashedPwd = $StaffData["StaffPwd"];
    // Debug output for hashed password
    echo "Stored Hashed Password: " . $hashedPwd . "<br>";
    echo "Entered Password: " . $Staffpassword . "<br>";

    // Verify the provided password against the hashed password
    if (!password_verify($Staffpassword, $hashedPwd)) {
        header("Location: ../LoginPageS.php?error=wronglogin");
        exit();
    } else {
        // Start a session and store user data if the password is correct
        session_start();
        $_SESSION["Staff_ID"] = $StaffData["Staff_ID"];
        $_SESSION["Staff_Name"] = $StaffData["Staff_Name"];
        header("Location: ../mainMenu.php");
        exit();
    }
}


