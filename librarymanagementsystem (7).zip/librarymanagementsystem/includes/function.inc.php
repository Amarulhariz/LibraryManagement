<?php
// Check for empty input in the signup form
function emptyInputSignup($ID, $name, $email, $phoneNum, $password, $Rpassword) {
    return empty($ID) || empty($name) || empty($email) || empty($phoneNum) || empty($password) || empty($Rpassword);
}

// Validate ID
function invalidID($ID) {
    return !preg_match("/^[a-zA-Z0-9]*$/", $ID);
}

// Validate name
function invalidName($name) {
    return !preg_match("/^[a-zA-Z0-9]*$/", $name);
}

// Validate email
function invalidEmail($email) {
    return !filter_var($email, FILTER_VALIDATE_EMAIL);
}

// Validate phone number
function invalidPhoneNumber($phoneNum) {
    return !preg_match("/^[0-9]*$/", $phoneNum);
}

// Check if passwords match
function pwdMatch($password, $Rpassword) {
    return $password !== $Rpassword;
}

// Check if user exists
function userNameExist($conn, $ID, $name, $email, $phoneNum) {
    $sql = "SELECT * FROM student WHERE Student_ID = ? OR Student_Name = ? OR Student_Address = ? OR StudentPhoneNumber = ?;";
    $stmt = mysqli_stmt_init($conn);
    if (!mysqli_stmt_prepare($stmt, $sql)) {
        header("Location: ../CreateAccount.php?error=stmtfailed");
        exit();
    }

    mysqli_stmt_bind_param($stmt, "ssss", $ID, $name, $email, $phoneNum);
    mysqli_stmt_execute($stmt);
    $resultData = mysqli_stmt_get_result($stmt);

    if ($row = mysqli_fetch_assoc($resultData)) {
        mysqli_stmt_close($stmt);
        return $row;
    } else {
        mysqli_stmt_close($stmt);
        return false;
    }
}

// Create a new user
function createUser($conn, $ID, $name, $email, $phoneNum, $password) {
    $sql = "INSERT INTO student (Student_ID, Student_Name, Student_Address, StudentPhoneNumber, StudentPwd) VALUES (?, ?, ?, ?, ?);";
    $stmt = mysqli_stmt_init($conn);
    if (!mysqli_stmt_prepare($stmt, $sql)) {
        header("Location: ../CreateAccount.php?error=stmtfailed");
        exit();
    }

    $hashedPwd = password_hash($password, PASSWORD_DEFAULT);
    mysqli_stmt_bind_param($stmt, "sssss", $ID, $name, $email, $phoneNum, $hashedPwd);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    header("Location: ../CreateAccount.php?error=none");
    exit();
}

// Check for empty input in the login form
function emptyInputLogin($ID, $password) {
    return empty($ID) || empty($password);
}

// Log in a user
function loginUser($conn, $ID, $password) {
    // Check if the user exists
    $userData = userNameExist($conn, $ID, '', '', '');

    if ($userData === false) {
        header("Location: ../LoginPage.php?error=wronglogin");
        exit();
    }

    // Retrieve the hashed password from the user data
    $hashedPwd = $userData["StudentPwd"];

    // Verify the provided password against the hashed password
    if (!password_verify($password, $hashedPwd)) {
        header("Location: ../LoginPage.php?error=wronglogin");
        exit();
    } else {
        // Start a session and store user data if the password is correct
        session_start();
        $_SESSION["Student_ID"] = $userData["Student_ID"];
        $_SESSION["Student_Name"] = $userData["Student_Name"];
        header("Location: ../mainMenu.php");
        exit();
    }
}

