<?php
if(isset($_POST["submit"])){
    $StaffID = $_POST["StaffID"];
    $Staffpassword = $_POST["StaffPwd"];

    require_once 'dbh.inc.php';
    require_once 'functionS.inc.php';

    if (emptyInputLoginS($StaffID, $Staffpassword)) {
        header("Location: ../LoginPageS.php?error=emptyinput");
        exit();
    }

    loginUserS($conn, $StaffID, $Staffpassword);
}
else {
    header("location: ../LoginPageS.php");
    exit();
}


