<?php
    $serverName="localhost";
    $dBuserName="root";
    $dBPassword="";
    $dBName="librarymanagement";

    $conn = mysqli_connect($serverName, $dBuserName, $dBPassword, $dBName);

    if(!$conn){
        die("Connection failed: " . mysqli_connect_error());
        
    }
