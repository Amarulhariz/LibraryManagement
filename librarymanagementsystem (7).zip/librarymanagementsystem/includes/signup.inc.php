<?php
if (isset($_POST["submit"])) {
    $ID = $_POST["StudentID"];
    $name = $_POST["StudentName"];
    $email = $_POST["StudentAddress"];
    $phoneNum = $_POST["StudentPhoneNum"];
    $password = $_POST["password"];
    $Rpassword = $_POST["Rpassword"];
    
    require_once 'dbh.inc.php';
    require_once 'function.inc.php';

    if (emptyInputSignup($ID ,$name, $email, $phoneNum, $password, $Rpassword)) {
        header("Location: ../CreateAccount.php?error=emptyinput");
        exit();
    }
    if (invalidID($ID)) {
        header("Location: ../CreateAccount.php?error=invalidID");
        exit();
    }

    if (invalidName($name)) {
        header("Location: ../CreateAccount.php?error=invalidname");
        exit();
    }

    if (invalidEmail($email)) {
        header("Location: ../CreateAccount.php?error=invalidemail");
        exit();
    }

    if (pwdMatch($password, $Rpassword)) {
        header("Location: ../CreateAccount.php?error=passworddontmatch");
        exit();
    }

    if (invalidPhoneNumber($phoneNum)) {
        header("Location: ../CreateAccount.php?error=invalidphonenumber");
        exit();
    }

    if (userNameExist($conn, $ID, $name, $email, $phoneNum)) {
        header("Location: ../CreateAccount.php?error=usernameexists");
        exit();
    }

    createUser($conn, $ID, $name, $email, $phoneNum, $password);
} else {
    header("Location: ../CreateAccount.php");
    exit();
}