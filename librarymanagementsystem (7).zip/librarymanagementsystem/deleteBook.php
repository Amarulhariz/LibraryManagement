<?php
include 'includes/dbh.inc.php'; // Include your database connection file

if (isset($_POST['book_code']) && !empty($_POST['book_code'])) {
    $book_code = mysqli_real_escape_string($conn, $_POST['book_code']);

    // Delete the book from all related tables
    $delete_physical = "DELETE FROM physicalbook WHERE Book_Code = '$book_code'";
    $delete_ebook = "DELETE FROM ebook WHERE Book_Code = '$book_code'";
    $delete_book = "DELETE FROM books WHERE Book_Code = '$book_code'";

    if (mysqli_query($conn, $delete_physical) && mysqli_query($conn, $delete_ebook) && mysqli_query($conn, $delete_book)) {
        echo "<script>
        alert('Book deleted successfully!');
        window.location.href = 'updateDeleteBook.php';
      </script>";
    } else {
        echo '<p>Error deleting book: ' . mysqli_error($conn) . '</p>';
    }
} else {
    echo '<p>No book code provided.</p>';
}

// Close connection
mysqli_close($conn);
