<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Approve.css">
    <link rel="stylesheet" href="SideBar.css">
    <title>Search Page</title>
</head>
<body>
<?php
session_start();
include 'includes/dbh.inc.php'; 

// SQL query to fetch pending requests
$sql = "SELECT r.Student_ID, r.Book_Code, e.EBook_Link, r.RequestID
        FROM request r
        JOIN ebook e ON e.Book_Code = r.Book_Code
        JOIN student s ON s.Student_ID = r.Student_ID
        WHERE r.Requested_Status = 'pending'";

$result = mysqli_query($conn, $sql);

// Check if any results were found
$queryResult = mysqli_num_rows($result);

if ($queryResult > 0) {
    echo '<div class="container">';
    echo '<h1>Approve E Book</h1>';
    echo '<form id="requestForm" action="" method="post">'; // Action points to the same page
    echo '<table>';
    echo '<tr><th>Select</th><th>Student ID</th><th>Book Code</th><th>EBook Link</th></tr>';

    while ($row = mysqli_fetch_assoc($result)) {
        echo '<tr>';
        echo '<td><input type="checkbox" name="selected_books[]" value="' . $row["Book_Code"] . '"></td>';
        echo '<td>' . $row["Student_ID"] . '</td>';
        echo '<td>' . $row["Book_Code"] . '</td>';
        echo '<td>' . $row["EBook_Link"] . '</td>'; // Display eBook link from ebook table
        echo '<input type="hidden" name="request_ids[]" value="' . $row["RequestID"] . '">';
        echo '<input type="hidden" name="ebook_links[]" value="' . $row["EBook_Link"] . '">';
        echo '</tr>';
    }

    echo '</table>';
    echo '<div class="button-container">'; // Added div with class button-container
    echo '<button type="submit" name="approve_submit" class="request-button approve-button">Approve Request</button>';
    echo '<button type="submit" name="Reject_submit" class="request-button reject-button">Reject Request</button>';
    echo '</div>';
    echo '</form>';
    echo '</div>';
}

if (isset($_SESSION["Staff_ID"])) {
    $staff = mysqli_real_escape_string($conn, $_SESSION["Staff_ID"]);
}

if (isset($_POST['approve_submit'])) {
    if (isset($_POST['selected_books']) && isset($_POST['request_ids']) && isset($_POST['ebook_links'])) {
        foreach ($_POST['selected_books'] as $key => $book_code) {
            // Fetch corresponding RequestID and EBook_Link
            $request_id = mysqli_real_escape_string($conn, $_POST['request_ids'][$key]);
            $ebook_link = mysqli_real_escape_string($conn, $_POST['ebook_links'][$key]);

            // Construct the UPDATE query
            $update_query = "UPDATE request 
                             SET EBook_Link = '$ebook_link', Requested_Status = 'approve', Staff_ID = '$staff' 
                             WHERE RequestID = '$request_id'";

            // Perform the query
            if (!mysqli_query($conn, $update_query)) {
                echo "Error updating request: " . mysqli_error($conn);
            }
        }

        echo "EBook links updated for selected requests.";
    } else {
        echo "No books selected for approval.";
    }
}

if (isset($_POST['Reject_submit'])) {
    if (isset($_POST['selected_books']) && isset($_POST['request_ids']) && isset($_POST['ebook_links'])) {
        foreach ($_POST['selected_books'] as $key => $book_code) {
            // Fetch corresponding RequestID and EBook_Link
            $request_id = mysqli_real_escape_string($conn, $_POST['request_ids'][$key]);
            $ebook_link = mysqli_real_escape_string($conn, $_POST['ebook_links'][$key]);

            // Construct the UPDATE query
            $update_query = "UPDATE request 
                             SET EBook_Link = '-', Requested_Status = 'reject', Staff_ID = '$staff' 
                             WHERE RequestID = '$request_id'";

            // Perform the query
            if (!mysqli_query($conn, $update_query)) {
                echo "Error updating request: " . mysqli_error($conn);
            }
        }

        echo "EBook links requests have been rejected.";
    } else {
        echo "No books selected for rejection.";
    }
}

?>
<?php include 'footer.php'; ?>

<div class="reference" onclick="toggleMenu()">
    <span></span>
    <span></span>
    <span></span>
</div>

<div id="sideMenu" class="sidebar">
    <button class="close-btn" onclick="toggleMenu()">&times;</button> <!-- Close Button -->
    <img src="gambar/MAHA1.png" alt="Profile Picture">
    <a href="mainMenu.php">Main Menu</a>
    <a href="ApprovePhysical.php">Approve Physical Book</a>
    <a href="ApproveEBook.php">Approve E-Books</a>
    <a href="ChooseReturnBook.php">Update Return Book</a>
</div>

<div class="overlay" onclick="toggleMenu()"></div>
<script>
function toggleMenu() {
    const reference = document.querySelector('.reference');
    const sidebar = document.getElementById('sideMenu');
    const overlay = document.querySelector('.overlay');

    reference.classList.toggle('toggle');
    sidebar.classList.toggle('show');
    overlay.classList.toggle('show');
}

// Initialize the overlay click event
document.addEventListener('DOMContentLoaded', function () {
    const overlay = document.querySelector('.overlay');
    overlay.addEventListener('click', toggleMenu);
});
</script>
<script src="script.js"></script>
</body>
</html>
