<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MAHA Library</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #fff;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            padding-top: 70px; /* Adjust this value based on the height of the header */
        }
        .header {
            background-color: #fff;
            padding: 10px 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-bottom: 2px solid #ddd;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            height: 70px; /* Adjust this value based on your header height */
            box-shadow: 0 2px 5px rgba(0,0,0,0.1); /* Optional for a shadow effect */
        }
        .header img {
            height: 100px;
            margin-left: 50px;
        }
        .header nav {
            display: flex;
            gap: 20px;
        }
        .header nav a {
            color: #000;
            text-decoration: none;
            font-size: 16px;
            font-weight: bold;
        }
        .hero {
            position: relative;
            height: 80vh;
            background: url('gambar/interface.jpg') no-repeat center center/cover;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: left;
            color: #fff;
            padding-left: 50px;
            overflow: hidden;
        }
        .hero .content {
            position: relative;
            z-index: 2;
            transition: transform 0.3s ease-out;
        }
        .hero::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1;
        }
        .hero h1 {
            font-size: 48px;
            margin: 0;
        }
        .hero p {
            font-size: 24px;
            margin: 20px;
        }
        .btn {
            padding: 10px 20px;
            background-color: #800080;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            margin-top: 20px;
            display: inline-block;
        }
        .content {
            flex: 1;
        }
        .spacer {
            height: 1000px;
        }
        footer {
            background-color: #d32f2f;
            color: white;
            text-align: center;
            padding: 10px 0;
            font-size: 14px;
            box-shadow: 0 -2px 5px rgba(0,0,0,0.2);
            margin-top: auto; /* Ensure footer sticks to the bottom */
        }
        .about-section {
            background: url('gambar/about us.jpg') no-repeat center center/cover;
            padding: 60px 20px;
            text-align: center;
            color: #fff;
        }
        .about-section h1 {
            font-size: 48px;
            margin-bottom: 20px;
        }
        .about-section p {
            font-size: 18px;
            line-height: 1.6;
            max-width: 800px;
            margin: 0 auto 20px;
        }
        .product-section {
            background: url('gambar/product.jpg') no-repeat center center/cover;
            padding: 60px 20px;
            text-align: center;
            color: #fff;
        }
        .product-section h1 {
            font-size: 48px;
            margin-bottom: 20px;
        }
        .product-section p {
            font-size: 18px;
            line-height: 1.6;
            max-width: 800px;
            margin: 0 auto 20px;
        }
    </style>
</head>
<body>
    <header class="header">
        <img src="gambar/MAHA1.png" alt="Company Logo" id="logo">
        <nav>
            <a href="interface.php">Home</a>
            <a href="#about">About Us</a>
            <a href="#product">Products</a>
            <a href="#footer">Contact Us</a>
            <a href="LoginPage.php">Log In</a>
            <a href="CreateAccount.php">Sign Up</a>
        </nav>
    </header>

    <section class="hero">
        <div class="content" id="hero">
            <h1>The Centre of Knowledge</h1>
            <p>Welcome to MAHA Library, the ultimate solution for efficient and user-friendly library management. Our state-of-the-art platform is designed to meet the needs of librarians, patrons, and administrators, providing a seamless experience for managing and accessing library resources. Whether you are overseeing a public library, academic institution, or private collection, MAHA Library is here to simplify and enhance your library operations.</p>
            <a href="#product" class="btn">See our products</a>
        </div>
    </section>

    <div class="content">
        <section class="about-section" id="about">
        <h1>About Us</h1>
            <h2>Welcome to MAHA Library: Revolutionizing Library Management</h2>
            <p><em>At MAHA Library, we are dedicated to transforming the way libraries operate in the digital age. Our mission is to provide an innovative, comprehensive, and user-friendly library management system that caters to the diverse needs of librarians, patrons, and administrators. With MAHA Library, managing and accessing library resources has never been easier.</em></p>
            <h2>Our Vision</h2> 
            <p><em>Our vision is to empower libraries worldwide with cutting-edge technology, fostering an environment where knowledge is easily accessible, and library operations are streamlined and efficient. We aim to be the leading solution in library management, setting new standards in service, reliability, and user satisfaction.</em></p>
            <h2>Our Mission</h2> 
            <p>Our mission is to create a seamless library management experience by integrating advanced tools and intuitive interfaces. We strive to support the evolving needs of libraries, enhance user engagement, and optimize library workflows, ensuring that every library can maximize its potential.</p>
        </section>

        <section class="product-section" id="product">
            <h1>Product</h1>
            <h2>Physical Book</h2>
            <p><em>Physical books remain a timeless and cherished medium for reading, offering a tactile and immersive experience. They come in various formats, including hardcover, paperback, and special editions, catering to different preferences and needs.</em></p>
            <h2>New Features : EBook</h2>
            <p><em>eBooks offer a modern, convenient way to read and access a vast library of titles. With recent advancements, eBooks now come with enhanced features that improve usability and engagement.</em></p>
            <p><em>Both physical books and eBooks offer unique advantages, catering to different reading preferences and lifestyles. Physical books provide a nostalgic, tactile experience, while eBooks offer convenience and advanced features that enhance the digital reading experience. Choose the format that best fits your needs, or enjoy the benefits of both with a hybrid approach to reading.</em><p>
        </section>
    </div>

    <footer id="footer">
        <p>&copy; 2024 MAHA Library Sdn. Bhd. (178134-P)</p>
        <p>Tel: 60-6-467 0630</p>
        <p>Fax: 60-6-469 2330</p>
        <p>Email: enquiry@mahalibrary.com</p>
        <p>Head Office: PT 3676, Jalan Mutiara, Seri Mendapat Industrial Park, 70400 Merlimau, Melaka, Malaysia</p>
    </footer>

    <script>
        // JavaScript to move the content on scroll
        window.addEventListener('scroll', function() {
            const scrollPosition = window.scrollY;
            const maxScroll = 300; // Maximum scroll distance for the effect
            const heroContent = document.getElementById('hero');

            // Calculate the new position
            const translateX = Math.min(scrollPosition, maxScroll);

            // Apply the translation
            heroContent.style.transform = `translateX(${translateX}px)`;
        });

        // Smooth scroll
        document.querySelector('a[href="#footer"]').addEventListener('click', function(event) {
            event.preventDefault();
            document.getElementById('footer').scrollIntoView({ behavior: 'smooth' });
        });

        document.querySelector('a[href="#about"]').addEventListener('click', function(event) {
            event.preventDefault();
            document.getElementById('about').scrollIntoView({ behavior: 'smooth' });
        });

        document.querySelector('a[href="#product"]').addEventListener('click', function(event) {
            event.preventDefault();
            document.getElementById('product').scrollIntoView({ behavior: 'smooth' });
        });
    </script>
</body>
</html>
