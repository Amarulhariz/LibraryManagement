<?php
session_start();
include 'includes/dbh.inc.php';

// Check if the student is logged in
if (isset($_SESSION['Student_ID'])) {
    $student = $_SESSION['Student_ID'];
    
    // Fetch student data from the database
    $sql = "SELECT * FROM student WHERE Student_ID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $student);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
} else {
    // Redirect to login if not logged in
    header("Location: LoginPage.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Profilestudent.css">
    <title>Student Profile</title>
</head>
<body>
    <div class="sidebar">
        <img src="gambar/profile picture.png" alt="Profile Picture">
        <h1>Welcome, <?php echo htmlspecialchars($user['Student_Name'] ?? 'Student'); ?></h1>
        <div class="sidebar_title">
            <a href="mainMenu.php">HOME</a>
            <a href="ProfileStudent.php">STUDENT PROFILE</a>
            <a href="editStudent.php">EDIT PROFILE</a>
            <a href="includes/logout.inc.php">LOG OUT</a>
        </div>
    </div>
    
    <div class="content">
        <h1>Student Details</h1>
        <div class="box">
            <h3>Student Details</h3>
            <ul>
                <li>
                    <label>Name:</label>
                    <span><?php echo htmlspecialchars($user['Student_Name']); ?></span>
                </li>
                <li>
                    <label>Phone Number:</label>
                    <span><?php echo htmlspecialchars($user['StudentPhoneNumber']); ?></span>
                </li>
                <li>
                    <label>Email Address:</label>
                    <span><?php echo htmlspecialchars($user['Student_Address']); ?></span>
                </li>
            </ul>
        </div>
    </div>
</body>
</html>
