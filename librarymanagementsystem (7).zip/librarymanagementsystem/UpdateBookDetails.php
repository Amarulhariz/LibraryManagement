<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Book Details</title>
    <style>
        body, html {
            height: 100%;
            margin: 0;
            background-color: #f4f4f4;
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .container {
            width: 80%;
            margin: 0 auto;
            padding: 20px;
            background-color: #f9f9f9;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }

        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }

        form {
            display: flex;
            flex-wrap: wrap; /* Allow elements to wrap onto the next line */
            justify-content: center; /* Center items horizontally */
        }

        .form-group {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
            width: 100%;
        }

        .form-group label {
            width: 120px; /* Fixed width for labels */
            font-weight: bold;
            color: #555;
            text-align: right; /* Align labels to the right */
            padding-right: 15px; /* Add some spacing between label and input */
        }

        .form-group input[type="text"] {
            flex: 1; /* Take remaining space */
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        .update-button {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            margin-left: 135px; /* Adjust margin to align button with inputs */
        }

        .update-button:hover {
            background-color: #45a049;
        }

        p {
            text-align: center;
            color: #555;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Update Book Details</h1>

        <?php
        session_start();
        include 'includes/dbh.inc.php'; // Include your database connection file

        if (isset($_POST['book_code']) && !empty($_POST['book_code'])) {
            $book_code = mysqli_real_escape_string($conn, $_POST['book_code']);

            // Fetch current book details
            $sql = "SELECT * FROM books WHERE Book_Code = '$book_code'";
            $result = mysqli_query($conn, $sql);

            if (mysqli_num_rows($result) > 0) {
                $row = mysqli_fetch_assoc($result);

                echo '<form method="post" action="" class="update-form">';
                echo '<input type="hidden" name="book_code" value="' . $row['Book_Code'] . '">';

                // Book Name field
                echo '<div class="form-group">';
                echo '<label for="book_name">Book Name:</label>';
                echo '<input type="text" id="book_name" name="book_name" value="' . $row['Book_Name'] . '" required>';
                echo '</div>';

                // Book Author field
                echo '<div class="form-group">';
                echo '<label for="book_author">Book Author:</label>';
                echo '<input type="text" id="book_author" name="book_author" value="' . $row['Book_Author'] . '" required>';
                echo '</div>';

                // Book Genre field
                echo '<div class="form-group">';
                echo '<label for="book_genre">Book Genre:</label>';
                echo '<input type="text" id="book_genre" name="book_genre" value="' . $row['Book_Genre'] . '" required>';
                echo '</div>';

                // Update button
                echo '<button type="submit" class="update-button">Update</button>';
                echo '</form>';
            } else {
                echo '<p>No book found with the provided code.</p>';
            }
        } else {
            echo '<p>No book code provided.</p>';
        }

        // Handle form submission for updating book details
        if (isset($_POST['book_name']) && !empty($_POST['book_name']) &&
            isset($_POST['book_author']) && !empty($_POST['book_author']) &&
            isset($_POST['book_genre']) && !empty($_POST['book_genre'])) {
            $book_code = mysqli_real_escape_string($conn, $_POST['book_code']);
            $book_name = mysqli_real_escape_string($conn, $_POST['book_name']);
            $book_author = mysqli_real_escape_string($conn, $_POST['book_author']);
            $book_genre = mysqli_real_escape_string($conn, $_POST['book_genre']);
        
            // Update query for the book details
            $update_query = "UPDATE books SET Book_Name = '$book_name', Book_Author = '$book_author', Book_Genre = '$book_genre' WHERE Book_Code = '$book_code'";
        
            if (mysqli_query($conn, $update_query)) {
                echo '<p>Book details updated successfully.</p>';
            } else {
                echo '<p>Error updating book details: ' . mysqli_error($conn) . '</p>';
            }
        }

        // Close connection
        mysqli_close($conn);

        include 'footer.php'; // Assuming footer.php includes your footer content
        ?>
    </div>
</body>
</html>
