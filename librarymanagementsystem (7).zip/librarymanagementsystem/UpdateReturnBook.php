<?php
session_start();
include 'includes/dbh.inc.php'; // Include your database connection file

if (isset($_POST['book_code']) && !empty($_POST['book_code'])) {
    $book_code = mysqli_real_escape_string($conn, $_POST['book_code']);
    // Fetch details of the selected book borrowing record
    $sql = "SELECT * FROM borrowing_record WHERE Book_Code = '$book_code'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);

        // Display the selected borrowing details in a form for updating
        echo '<div class="container">';
        echo '<h1>Update Return Details</h1>';
        echo '<form action="" method="post" class="update-form">';
        echo '<input type="hidden" name="book_code" value="' . $row['Book_Code'] . '">';
        echo '<table class="update-table">';
        echo '<tr><th>Book Code</th><th>Student ID</th><th>Borrowing Date</th><th>Borrowing Time</th><th>Returning Time</th><th>Returning Date</th><th>Status</th></tr>';
        echo '<tr>';
        echo '<td>' . $row['Book_Code'] . '</td>';
        echo '<td>' . $row['Student_ID'] . '</td>';
        echo '<td>' . $row['Borrowing_Date'] . '</td>';
        echo '<td>' . $row['Borrowing_Time'] . '</td>';
        echo '<td><input type="text" name="Returning_Time" value="' . $row['Returning_Time'] . '"></td>';
        echo '<td><input type="date" name="Returning_Date" value="' . $row['Returning_Date'] . '"></td>';
        echo '<td><input type="text" name="Status_Borrowing" value="' . $row['Status_Borrowing'] . '"></td>';
        echo '</tr>';
        echo '</table>';
        echo '<button type="submit" name="update_submit" class="update-button">Update Return Details</button>';
        echo '</form>';
        echo '</div>';
    } else {
        echo "<p>No borrowing record found with the selected code.</p>";
    }
}

if (isset($_POST['update_submit'])) {
    // Retrieve and sanitize inputs
    $book_code = mysqli_real_escape_string($conn, $_POST['book_code']);
    $returning_time = mysqli_real_escape_string($conn, $_POST['Returning_Time']);
    $returning_date = mysqli_real_escape_string($conn, $_POST['Returning_Date']);
    $status_borrowing = mysqli_real_escape_string($conn, $_POST['Status_Borrowing']);


    // Update query for the borrowing record
    $update_query = "UPDATE borrowing_record SET Returning_Time = '$returning_time', Returning_Date = '$returning_date', Status_Borrowing = '$status_borrowing' WHERE Book_Code = '$book_code'";

    if (mysqli_query($conn, $update_query)) {
        if (trim($status_borrowing) === 'return') {
            // Update physical book status to available
            $update_book_query = "UPDATE physicalbook SET PBookCode_Status = 'Available' WHERE Book_Code = '$book_code'";
            if (!mysqli_query($conn, $update_book_query)) {
                echo "Error updating book status: " . mysqli_error($conn);
            } else {
                echo '<div class="container">';
                echo '<h1>Update Successful</h1>';
                echo '<p>Return details updated successfully and book status set to available.</p>';
                echo '</div>';
            }
        } else {
            echo '<div class="container">';
            echo '<h1>Update Successful</h1>';
            echo '<p>Return details updated successfully.</p>';
            echo '</div>';
        }
    } else {
        echo '<div class="container">';
        echo '<h1>Error</h1>';
        echo '<p>Failed to update return details: ' . mysqli_error($conn) . '</p>';
        echo '</div>';
    }
}

// Close connection
mysqli_close($conn);

include 'footer.php'; 
?>

<style>
    .container {
        width: 80%;
        margin: 0 auto;
        padding: 20px;
        background-color: #f9f9f9;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    h1 {
        text-align: center;
        color: #333;
    }

    .update-form {
        display: flex;
        flex-direction: column;
        align-items: center;
    }

    .update-table {
        width: 100%;
        margin-bottom: 20px;
        border-collapse: collapse;
    }

    .update-table th, .update-table td {
        padding: 10px;
        border: 1px solid #ddd;
        text-align: left;
    }

    .update-table th {
        background-color: #f2f2f2;
    }

    .update-button {
        padding: 10px 20px;
        background-color: #4CAF50;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-size: 16px;
    }

    .update-button:hover {
        background-color: #45a049;
    }

    p {
        text-align: center;
        color: #555;
    }
</style>
