<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Website with Navigation</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        .navbar {
            background-color: #333;
            overflow: hidden;
        }
        .navbar a {
            float: right; /* Align links to the right */
            display: block;
            color: #f2f2f2;
            text-align: center;
            padding: 14px 20px;
            text-decoration: none;
        }
        .navbar a:hover {
            background-color: #ddd;
            color: black;
        }
    </style>
</head>
<body>

    <div class="navbar">
        <?php
        if(isset($_SESSION["Student_ID"])){
            echo " <a href='profile.php'>profile</a>";
            echo "<a href='includes/Logout.inc.php'>Log out</a>";
        }
        else if(isset($_SESSION["Staff_ID"])){
            echo " <a href='profile.php'>profilea</a>";
            echo "<a href='includes/Logout.inc.php'>Log out</a>";
        }
        else{
            echo " <a href='CreateAccount.php'>Sign in</a>";
            echo "<a href='LoginPage.php'>Log in</a>";
        }
        ?>

        
        <a href="mainMenu.php">Home</a>
    </div>

    
