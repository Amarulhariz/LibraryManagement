<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="ChooseReturn.css">
    <link rel="stylesheet" href="SideBar.css">
    <title>Manage Borrowing Records</title>
</head>
<body>
    <div class="container">
        <h1>Manage Borrowing Records</h1>

        <?php
        // Include necessary files
        session_start();
        include 'includes/dbh.inc.php'; // Include your database connection file

        // Prepare SQL statement
        $sql = "SELECT * FROM borrowing_record WHERE Status_Borrowing = 'Inborrowing'";

        // Execute query
        $result = mysqli_query($conn, $sql);

        // Check if any results were found
        if (mysqli_num_rows($result) > 0) {
            // Output the results in a table
            echo '<table>';
            echo '<tr>
                    <th>Book Code</th>
                    <th>Staff ID</th>
                    <th>Student ID</th>
                    <th>Borrowing Date</th>
                    <th>Borrowing Time</th>
                    <th>Returning Date</th>
                    <th>Returning Time</th>
                    <th>Status</th>
                    <th>Action</th>
                  </tr>';

            // Loop through each row in the result set and display the data
            while ($row = mysqli_fetch_assoc($result)) {
                echo '<tr>';
                echo "<td>" . $row["Book_Code"] . "</td>";
                echo "<td>" . $row["Staff_ID"] . "</td>";
                echo "<td>" . $row["Student_ID"] . "</td>";
                echo "<td>" . $row["Borrowing_Date"] . "</td>";
                echo "<td>" . $row["Borrowing_Time"] . "</td>";
                echo "<td>" . $row["Returning_Date"] . "</td>";
                echo "<td>" . $row["Returning_Time"] . "</td>";
                echo "<td>" . $row["Status_Borrowing"] . "</td>";
                echo '<td>';
                echo '<form method="post" action="UpdateReturnBook.php" style="display: inline;">';
                echo '<input type="hidden" name="book_code" value="' . $row["Book_Code"] . '">';
                echo '<button type="submit" class="btn update-button">Update</button>';
                echo '</form>';
                echo '</td>';
                echo '</tr>';
            }

            echo '</table>';
        } else {
            echo "<p>No borrowing records found.</p>";
        }

        // Close connection
        mysqli_close($conn);
        ?>

    </div>
    <?php include 'footer.php'; // Assuming footer.php includes your footer content ?>
    <div class="reference" onclick="toggleMenu()">
    <span></span>
    <span></span>
    <span></span>
</div>

<div id="sideMenu" class="sidebar">
    <button class="close-btn" onclick="toggleMenu()">&times;</button> <!-- Close Button -->
    <img src="gambar/MAHA1.png" alt="Profile Picture">
    <a href="mainMenu.php">Main Menu</a>
    <a href="ApprovePhysical.php">Approve Physical Book</a>
    <a href="ApproveEBook.php">Approve E-Books</a>
    <a href="ChooseReturnBook.php">Update Return Book</a>
</div>

<div class="overlay" onclick="toggleMenu()"></div>
<script>
function toggleMenu() {
    const reference = document.querySelector('.reference');
    const sidebar = document.getElementById('sideMenu');
    const overlay = document.querySelector('.overlay');

    reference.classList.toggle('toggle');
    sidebar.classList.toggle('show');
    overlay.classList.toggle('show');
}

// Initialize the overlay click event
document.addEventListener('DOMContentLoaded', function () {
    const overlay = document.querySelector('.overlay');
    overlay.addEventListener('click', toggleMenu);
});
</script>
<script src="script.js"></script>
</body>
</html>
