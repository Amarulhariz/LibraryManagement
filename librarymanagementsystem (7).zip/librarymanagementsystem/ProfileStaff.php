<?php
session_start();
include 'includes/dbh.inc.php';

// Check if the staff is logged in
if (isset($_SESSION['Staff_ID'])) {
    $staff = $_SESSION['Staff_ID'];
    
    // Fetch user data from the database
    $sql = "SELECT * FROM staff WHERE Staff_ID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $staff);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
} else {
    // Redirect to login if not logged in
    header("Location: profile.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Profilestaff.css">
    <title>Staff Profile</title>
</head>
<body>
    <div class="sidebar">
        <img src="gambar/amarul.jpg" alt="Profile Picture">
        <h1>Welcome, <?php echo htmlspecialchars($user['Staff_Name'] ?? 'Staff'); ?></h1>
        <div class="sidebar_title">
            <a href="mainMenu.php">HOME</a>
            <a href="ProfileStaff.php">STAFF PROFILE</a>
            <a href="editStaff.php">EDIT PROFILE</a>
            <a href="includes/logout.inc.php">LOG OUT</a>
        </div>
    </div>
    
    <div class="content">
        <h1>Staff Details</h1>
        <div class="box">
            <h3>Staff Details</h3>
            <ul>
                <li>
                    <label>Name:</label>
                    <span><?php echo htmlspecialchars($user['Staff_Name']); ?></span>
                </li>
                <li>
                    <label>Phone Number:</label>
                    <span><?php echo htmlspecialchars($user['StaffPhone_Num']); ?></span>
                </li>
                <li>
                    <label>Email Address:</label>
                    <span><?php echo htmlspecialchars($user['StaffEmail']); ?></span>
                </li>
            </ul>
        </div>
    </div>
</body>
</html>
