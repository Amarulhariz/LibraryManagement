<?php
    session_start();
    include_once 'includes/dbh.inc.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&family=Montserrat:wght@600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="mainMenu.css">
</head>
<body>
    <div class="sidebar">
        <img src="gambar/MAHA1.png" alt="Company Logo" id="logo">
        
        <nav>
            <?php
            if(isset($_SESSION["Student_ID"])){
                echo "<a href='mainMenu.php'>Home</a>";
                echo "<a href='ProfileStudent.php'>Profile</a>";
                echo "<a href='searchBook.php'>Search Book</a>";
                echo "<a href='RequestPhysical.php'>Request Physical Book</a>";
                echo "<a href='RequestEbook.php'>Request EBook</a>";
                echo "<a href='viewRequestPhysical.php'>View Request Physical Books</a>";
                echo "<a href='viewRequestEbook.php'>View Request EBooks</a>";
                echo "<a href ='includes/logout.inc.php'>Log out</a>";
                
            }
            elseif (isset($_SESSION["Staff_ID"]))
            {
                $staff = $_SESSION["Staff_ID"];
                if ($staff != '20123'){
                echo " <a href='EditStaff.php'>Edit profile</a>";
                echo "<a href='ApproveEBook.php'>Approve Requested E-Book</a>";
                echo "<a href='ApprovePhysical.php'>Approve Requested Physical Book</a>";
                echo "<a href ='ChooseReturnBook.php'>Returning Book</a>";
                echo "<a href ='includes/logout.inc.php'>Log out</a>";
                }
                elseif ($staff = '20123')
                {
                    echo " <a href='EditStaff.php'>Edit profile</a>";
                    echo " <a href='AddBook.php'>Add new Book</a>";
                    echo " <a href='UpdateDeleteBook.php'>Update and Delete new Book</a>";
                    echo " <a href='GenerateRecord.php'>Print Borrowing Record</a>";
                    echo "<a href ='includes/logout.inc.php'>Log out</a>";
                }
            }
           
            else{
                echo " <a href='CreateAccount.php'>Sign in</a>";
                echo "<a href='LoginPage.php'>Log in</a>";
            }
            ?>
        </nav>
    </div>
    <div class="main-content">
        <div class="header">
        <?php
        if (isset($_SESSION["Student_Name"])) {
            $student = $_SESSION["Student_Name"];
            echo '<div class="welcome"><h1>Welcome, ' . htmlspecialchars($student) . '</h1></div>';
        }
        elseif (isset($_SESSION["Staff_Name"]))
        {
            $staff = $_SESSION["Staff_Name"];
            echo '<div class="welcome"><h1>Welcome, ' . htmlspecialchars($staff) . '</h1></div>';
        }
        ?>
        </div>
        <div class="dashboard">
            <div class="card">
                <h3>Total Titles</h3>
                <p class="counter" data-target="3854">0</p>
            </div>
            <div class="card">
                <h3>Total Authors</h3>
                <p class="counter" data-target="2907">0</p>
            </div>
            <div class="card">
                <h3>Total Publisher</h3>
                <p class="counter" data-target="1021">0</p>
            </div>
            <div class="card">
                <h3>Total Price of Books</h3>
                <p class="counter" data-target="875973.91">$0</p>
            </div>
            <div class="card">
                <h3>Total Staffs</h3>
                <p class="counter" data-target="5">0</p>
            </div>
            <div class="card">
                <img src="gambar/MAHA1.png" alt="Library Image">
            </div>
            <div class="card">
                <h3>Total Books</h3>
                <p class="counter" data-target="6637">0</p>
            </div>
            <div class="card">
                <h3>Total Students</h3>
                <p class="counter" data-target="5463">0</p>
            </div>
            <div class="card">
                <h3>Total Borrowed</h3>
                <p class="counter" data-target="196">0</p>
            </div>
            <div class="card">
                <h3>Total Returned</h3>
                <p class="counter" data-target="46">0</p>
            </div>
        </div>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const counters = document.querySelectorAll('.counter');
            counters.forEach(counter => {
                counter.innerText = '0';
                const updateCounter = () => {
                    const target = +counter.getAttribute('data-target');
                    const current = +counter.innerText.replace(/[^0-9.-]+/g, '');
                    const increment = target / 200;

                    if (current < target) {
                        counter.innerText = `${Math.ceil(current + increment)}`;
                        setTimeout(updateCounter, 20);
                    } else {
                        counter.innerText = target;
                    }
                };
                updateCounter();
            });
        });
    </script>
</body>
</html>
<?php
    include_once 'footer.php';
?>