<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">    
    <link rel="stylesheet" href="RequestPhysical.css">
    <link rel="stylesheet" href="SideBar.css">
    <title>Request E-Book</title>
</head>
<body>
    <div class="container">
        <div class="content">
            <h1>Request Physical Book</h1>
            <img src="gambar/bukul.png" alt="E-Book Icon" class="ebook-icon">
            <h1>"Facilitate your search at your fingertips."</h1>
            <form action="RequestP.php" method="post">
                <div class="search-box">
                    <input type="text" placeholder="Search Book" name="bookNameS">
                </div>
                <div class="search-box">
                    <button class="request-button" name="request">Search</button>
                </div>
            </form>
        </div>
    </div>
    <div class="reference" onclick="toggleMenu()">
    <span></span>
    <span></span>
    <span></span>
</div>

<div id="sideMenu" class="sidebar">
    <button class="close-btn" onclick="toggleMenu()">&times;</button> <!-- Close Button -->
    <img src="gambar/MAHA1.png" alt="Profile Picture">
    <a href="mainMenu.php">Main Menu</a>
    <a href="searchBook.php">Search Book</a>
    <a href="RequestPhysical.php">Request Physical Books</a>
    <a href='RequestEbook.php'>Request EBook</a>
    <a href='viewRequestPhysical.php'>View Request Physical Books</a>
    <a href='viewRequestEbook.php'>View Request EBooks</a>
</div>

<div class="overlay" onclick="toggleMenu()"></div>
<script>
function toggleMenu() {
    const reference = document.querySelector('.reference');
    const sidebar = document.getElementById('sideMenu');
    const overlay = document.getElementById('overlay');

    reference.classList.toggle('toggle');
    sidebar.classList.toggle('show');
    overlay.classList.toggle('show');
}

// Initialize the overlay click event
document.addEventListener('DOMContentLoaded', function () {
    const overlay = document.getElementById('overlay');
    overlay.addEventListener('click', toggleMenu);
});

</script>
<script src="script.js"></script>
</body>
</html>
