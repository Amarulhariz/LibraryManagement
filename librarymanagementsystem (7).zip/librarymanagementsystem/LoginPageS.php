<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="LoginPage.css">
    <title>Login Page</title>
</head>
<body>
<div class="container">
    <div class="left-half">
        <div class="logo">
            <img src="gambar/MAHA1.png" alt="Logo">
        </div>
        <div class="login-container">
            <h2>STAFF LOGIN</h2>
            <form action="includes/LoginS.inc.php" method="post">
                <input type="text" id="StaffID" name="StaffID" placeholder="Staff ID" required>
                <br>
                <input type="password" id="StaffPwd" name="StaffPwd" placeholder="Password" required>
                <br>
                <button type="submit" name="submit">LOGIN</button>
                <div class="login-con">
                <h3>     OR     </h3>
                </div>
                <button onclick="goToStaffLogin()">Login as Student</button>
            </form>
            
        </div>
        <?php
        if (isset($_GET["error"])) {
            if ($_GET["error"] == "emptyinput") {
                echo "<p>Fill in all fields!</p>";
            } elseif ($_GET["error"] == "wronglogin") {
                echo "<p>Incorrect login information</p>";
            }
        }
        ?>
    </div>
    <div class="right-half">
        <img src="gambar/book.png" alt="Books" class="image-box">
    </div>
    <script>
    function goToStaffLogin() {
        window.location.href = 'LoginPage.php';
    }
    </script>
</div>

</body>
</html>
