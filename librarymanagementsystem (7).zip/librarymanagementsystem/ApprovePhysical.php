<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Approve.css">
    <link rel="stylesheet" href="SideBar.css">
    <title>Search Page</title>
</head>
<body>
<?php
session_start();
include 'includes/dbh.inc.php'; 

// SQL query to fetch pending requests
$sql = "SELECT r.Student_ID, r.Book_Code, r.RequestPID, r.PickUp_Date, r.PickUp_Time
        FROM requestP r
        JOIN student s ON s.Student_ID = r.Student_ID
        WHERE r.RequestedP_Status = 'pending'";

$result = mysqli_query($conn, $sql);

// Check if any results were found
$queryResult = mysqli_num_rows($result);

if ($queryResult > 0) {
    echo '<div class="container">';
    echo '<h1>Approve Physical Book</h1>';
    echo '<form id="requestForm" action="" method="post">'; // Action points to the same page
    echo '<table>';
    echo '<tr><th>Select</th><th>Student ID</th><th>Book Code</th><th>Pick Up Date</th><th>Pick Up Time</th></tr>';

    while ($row = mysqli_fetch_assoc($result)) {
        echo '<tr>';
        echo '<td><input type="checkbox" name="selected_books[]" value="' . $row["Book_Code"] . '"></td>';
        echo '<td><input type="hidden" name="student_ids[]" value="' . $row["Student_ID"] . '">' . $row["Student_ID"] . '</td>';
        echo '<td>' . $row["Book_Code"] . '</td>';
        echo '<td><input type="hidden" name="pick_up_dates[]" value="' . $row["PickUp_Date"] . '">' . $row["PickUp_Date"] . '</td>';
        echo '<td><input type="hidden" name="pick_up_times[]" value="' . $row["PickUp_Time"] . '">' . $row["PickUp_Time"] . '</td>';
        echo '<input type="hidden" name="request_ids[]" value="' . $row["RequestPID"] . '">';
        echo '</tr>';
    }

    echo '</table>';
    echo '<div class="button-container">'; // Added div with class button-container
    echo '<button type="submit" name="approve_submit" class="request-button approve-button">Approve Request</button>';
    echo '<button type="submit" name="Reject_submit" class="request-button reject-button">Reject Request</button>';
    echo '</div>';
    echo '</form>';
    echo '</div>';
}

if (isset($_SESSION["Staff_ID"])) {
    $staff = mysqli_real_escape_string($conn, $_SESSION["Staff_ID"]);
}

if (isset($_POST['approve_submit'])) {
    if (isset($_POST['selected_books']) && isset($_POST['request_ids'])) {
        foreach ($_POST['selected_books'] as $key => $book_code) {
            $book_code = mysqli_real_escape_string($conn, $book_code);
            $request_id = mysqli_real_escape_string($conn, $_POST['request_ids'][$key]);
            $student_id = mysqli_real_escape_string($conn, $_POST['student_ids'][$key]);
            $pick_up_date = mysqli_real_escape_string($conn, $_POST['pick_up_dates'][$key]);
            $pick_up_time = mysqli_real_escape_string($conn, $_POST['pick_up_times'][$key]);

            // Update request status
            $update_query = "UPDATE requestp 
                             SET RequestedP_Status = 'approve', Staff_ID = '$staff' 
                             WHERE RequestPID = '$request_id'";

            if (mysqli_query($conn, $update_query)) {
                // Insert into borrowing table
                $borrow_query = "INSERT INTO borrowing_record (Book_Code, Staff_ID, Student_ID, Borrowing_Time, Borrowing_Date, Status_Borrowing)
                                 VALUES ('$book_code', '$staff', '$student_id', '$pick_up_time', '$pick_up_date', 'InBorrowing')";

                if (mysqli_query($conn, $borrow_query)) {
                    // Update physical book status to unavailable
                    $update_book_query = "UPDATE physicalbook 
                                          SET PBookCode_Status = 'unavailable' 
                                          WHERE Book_Code = '$book_code'";
                    if (!mysqli_query($conn, $update_book_query)) {
                        echo "Error updating book status: " . mysqli_error($conn);
                    }
                } else {
                    echo "Error inserting borrowing record: " . mysqli_error($conn);
                }
            } else {
                echo "Error updating request: " . mysqli_error($conn);
            }
        }

        echo "Physical book updated and borrowing records inserted for selected requests.";
    } else {
        echo "No books selected for approval.";
    }
}

if (isset($_POST['Reject_submit'])) {
    if (isset($_POST['selected_books']) && isset($_POST['request_ids'])) {
        foreach ($_POST['selected_books'] as $key => $book_code) {
            $book_code = mysqli_real_escape_string($conn, $book_code);
            $request_id = mysqli_real_escape_string($conn, $_POST['request_ids'][$key]);

            // Update request status to reject
            $update_query = "UPDATE requestp
                             SET RequestedP_Status = 'reject', Staff_ID = '$staff' 
                             WHERE RequestPID = '$request_id'";

            if (!mysqli_query($conn, $update_query)) {
                echo "Error updating request: " . mysqli_error($conn);
            }
        }

        echo "Physical requests have been rejected.";
    } else {
        echo "No books selected for rejection.";
    }
}
?>
<?php include 'footer.php'; ?>
<div class="reference" onclick="toggleMenu()">
    <span></span>
    <span></span>
    <span></span>
</div>

<div id="sideMenu" class="sidebar">
    <button class="close-btn" onclick="toggleMenu()">&times;</button> <!-- Close Button -->
    <img src="gambar/MAHA1.png" alt="Profile Picture">
    <a href="mainMenu.php">Main Menu</a>
    <a href="ApprovePhysical.php">Approve Physical Book</a>
    <a href="ApproveEBook.php">Approve E-Books</a>
    <a href="ChooseReturnBook.php">Update Return Book</a>
</div>

<div class="overlay" onclick="toggleMenu()"></div>
<script>
function toggleMenu() {
    const reference = document.querySelector('.reference');
    const sidebar = document.getElementById('sideMenu');
    const overlay = document.getElementById('overlay');

    reference.classList.toggle('toggle');
    sidebar.classList.toggle('show');
    overlay.classList.toggle('show');
}

// Initialize the overlay click event
document.addEventListener('DOMContentLoaded', function () {
    const overlay = document.getElementById('overlay');
    overlay.addEventListener('click', toggleMenu);
});

</script>
<script src="script.js"></script>
</body>
</html>
