<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="LoginPage.css">
    <title>Login Page</title>
</head>
<body>
<div class="container">
    <div class="left-half">
        <div class="logo">
            <img src="gambar/MAHA1.png" alt="Logo">
        </div>
        <div class="login-container">
            <h2>STUDENT LOGIN</h2>
            <form action="includes/login.inc.php" method="post" >
                <input type="text" id="StudentID" name="StudentID" placeholder="Student ID" required>
                <br>
                <input type="password" id="StudentPwd" name="StudentPwd" placeholder="Password" required>
                <br>
                <button type="submit" name="submit">LOGIN</button>
                <H4>OR</H4>
                <button onclick="goToStaffLogin()">Login as Staff</button>
            </form>
        </div>

        <?php
        if (isset($_GET["error"])) {
            if ($_GET["error"] == "emptyinput") {
                echo "<p>Fill in all fields!</p>";
            } elseif ($_GET["error"] == "wronglogin") {
                echo "<p>Incorrect login information</p>";
            }
        }
        ?>
    </div>
    <div class="right-half">
        <div class="image-box">
             <img src="gambar/book.png" alt="Books">
        </div>
   
</div>

<script>
    function goToStaffLogin() {
        window.location.href = 'LoginPageS.php';
    }
</script>
<script src="script.js"></script>

</body>
</html>
