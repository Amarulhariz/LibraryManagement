<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="SAfterSearch.css">
    <link rel="stylesheet" href="SideBar.css">
    <title>Search Page</title>
</head>
<body>
    <?php
    session_start();
    include 'includes/dbh.inc.php'; // Include your database connection file

    // Check if the form was submitted
    if(isset($_POST['bookNameS']) && !empty($_POST['bookNameS'])) {
        // prevent sql injection
        $search = mysqli_real_escape_string($conn, $_POST['bookNameS']);

        // basic sql
        $sql = "SELECT b.Book_Code, b.Book_Name, b.Book_Author, b.Book_Genre, p.PBookCode_Status, e.EBookCode_Status
                FROM books b
                JOIN physicalbook p ON p.Book_Code = b.Book_Code
                JOIN ebook e ON e.Book_Code = b.Book_Code
                WHERE Book_Name LIKE '%$search%' OR Book_Author LIKE '%$search%'";
        // Execute the query
        $result = mysqli_query($conn, $sql);

        // Check if any results were found
        $queryResult = mysqli_num_rows($result);

        if ($queryResult > 0) {
            // Output the results in a table
            echo '<div class="container">';
            echo '<h1>Search Results</h1>';
            echo '<table>';
            echo '<tr><th>Code</th><th>Name</th><th>Author</th><th>Genre</th><th>Physical Status</th><th>E-Book Status</th></tr>';

            // Loop through each row in the result set and display the data
            while($row = mysqli_fetch_assoc($result)) {
                echo '<tr>';
                echo "<td>" . $row["Book_Code"] . "</td>";
                echo "<td>" . $row["Book_Name"] . "</td>";
                echo "<td>" . $row["Book_Author"] . "</td>";
                echo "<td>" . $row["Book_Genre"] . "</td>";
                echo "<td>" . $row["PBookCode_Status"] . "</td>";
                echo "<td>" . $row["EBookCode_Status"] . "</td>";
                echo '</tr>';
            }

            echo '</table>';
            echo '</div>';
        } else {
            echo "<div class='container'>";
            echo "No Book matching '$search'";
            echo "</div>";
        }
    }
    ?>
    
    <?php include 'footer.php'; // Assuming footer.php includes your footer content ?>

    <div class="reference" onclick="toggleMenu()">
    <span></span>
    <span></span>
    <span></span>
</div>

<div id="sideMenu" class="sidebar">
    <button class="close-btn" onclick="toggleMenu()">&times;</button> <!-- Close Button -->
    <img src="gambar/MAHA1.png" alt="Profile Picture">
    <a href="mainMenu.php">Main Menu</a>
    <a href="searchBook.php">Search Book</a>
    <a href="RequestPhysical.php">Request Physical Books</a>
    <a href='RequestEbook.php'>Request EBook</a>
    <a href='viewRequestPhysical.php'>View Request Physical Books</a>
    <a href='viewRequestEbook.php'>View Request EBooks</a>
</div>

<div class="overlay" onclick="toggleMenu()"></div>

<script>
function toggleMenu() {
    const reference = document.querySelector('.reference');
    const sidebar = document.getElementById('sideMenu');
    const overlay = document.querySelector('.overlay');

    reference.classList.toggle('toggle');
    sidebar.classList.toggle('show');
    overlay.classList.toggle('show');
}

// Initialize the overlay click event
document.addEventListener('DOMContentLoaded', function () {
    const overlay = document.querySelector('.overlay');
    overlay.addEventListener('click', toggleMenu);
});
</script>

<script src="script.js"></script>
</body>
</html>
