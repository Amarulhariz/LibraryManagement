<?php

include 'includes/dbh.inc.php';

// Fetch records from the database with book details
$sql = "SELECT borrowing_Record.Student_ID, 
               borrowing_Record.Staff_ID, 
               borrowing_Record.Book_Code, 
               borrowing_Record.Borrowing_Time, 
               borrowing_Record.Borrowing_Date, 
               borrowing_Record.Returning_Time, 
               borrowing_Record.Returning_Date, 
               books.book_name,
               books.book_Author,
               books.Book_Genre
        FROM borrowing_Record
        JOIN books ON borrowing_Record.Book_Code = books.book_code";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Generate.css">
    <link rel="stylesheet" href="SideBar.css">
    <title>Borrowing Record</title>
</head>
<body>
    <h1>Borrowing Record Management</h1>

    <!-- Display Table of Records -->
    <div class="table-container">
        <h2 style ="text-align: center; color: black;">Borrowing Records</h2>
        <button class="print-button" onclick="window.print();">Print Records</button>
        <table>
            <thead>
                <tr>
                    <th>Student ID</th>
                    <th>Staff ID</th>
                    <th>Book Code</th>
                    <th>Book Name</th>
                    <th>Book Author</th>
                    <th>Book Genre</th>
                    <th>Borrowing Time</th>
                    <th>Borrowing Date</th>
                    <th>Returning Time</th>
                    <th>Returning Date</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>
                                <td>{$row['Student_ID']}</td>
                                <td>{$row['Staff_ID']}</td>
                                <td>{$row['Book_Code']}</td>
                                <td>{$row['book_name']}</td>
                                <td>{$row['book_Author']}</td>
                                <td>{$row['Book_Genre']}</td>
                                <td>{$row['Borrowing_Time']}</td>
                                <td>{$row['Borrowing_Date']}</td>
                                <td>{$row['Returning_Time']}</td>
                                <td>{$row['Returning_Date']}</td>
                            </tr>";
                    }
                } else {
                    echo "<tr><td colspan='10'>No records found.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

    <?php $conn->close(); ?>
    <div class="reference" onclick="toggleMenu()">
    <span></span>
    <span></span>
    <span></span>
</div>

<div id="sideMenu" class="sidebar">
    <button class="close-btn" onclick="toggleMenu()">&times;</button> <!-- Close Button -->
    <img src="gambar/MAHA1.png" alt="Profile Picture">
    <a href="mainMenu.php">Main Menu</a>
    <a href='AddBook.php'>Add new Book</a>
    <a href='UpdateDeleteBook.php'>Update and Delete new Book</a>
    <a href='GenerateRecord.php'>Print Borrowing Record</a>
</div>

<div class="overlay" onclick="toggleMenu()"></div>
<script>
function toggleMenu() {
    const reference = document.querySelector('.reference');
    const sidebar = document.getElementById('sideMenu');
    const overlay = document.getElementById('overlay');

    reference.classList.toggle('toggle');
    sidebar.classList.toggle('show');
    overlay.classList.toggle('show');
}

// Initialize the overlay click event
document.addEventListener('DOMContentLoaded', function () {
    const overlay = document.getElementById('overlay');
    overlay.addEventListener('click', toggleMenu);
});

</script>
<script src="script.js"></script>
</body>
</html>
