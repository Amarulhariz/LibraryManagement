<?php
session_start();
include 'includes/dbh.inc.php';

// Check if the student is logged in
if (isset($_SESSION['Student_ID'])) {
    $studentID = $_SESSION['Student_ID'];
    
    // Fetch student data from the database
    $sql = "SELECT * FROM student WHERE Student_ID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $studentID);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $student = $result->fetch_assoc();
    } else {
        // Redirect to login if session student ID is not valid
        header("Location: LoginPage.php");
        exit();
    }
} else {
    // Redirect to login if not logged in
    header("Location: LoginPage.php");
    exit();
}

$message = "";

// Function to update student details
function updateStudentDetails($conn, $studentID, $name, $phoneNum, $email)
{
    $sql = "UPDATE student SET Student_Name=?, StudentPhoneNumber=?, Student_Address=? WHERE Student_ID=?";
    
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        return "Error preparing statement: " . $conn->error;
    }

    $stmt->bind_param("sssi", $name, $phoneNum, $email, $studentID);
    if ($stmt->execute()) {
        return true;
    } else {
        return "Error updating record: " . $stmt->error;
    }
}

// Function to update student password
function updateStudentPassword($conn, $studentID, $password)
{
    $sql = "UPDATE student SET Student_Password=? WHERE Student_ID=?";
    
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        return "Error preparing statement: " . $conn->error;
    }

    $stmt->bind_param("si", $password, $studentID);
    if ($stmt->execute()) {
        return true;
    } else {
        return "Error updating password: " . $stmt->error;
    }
}

if (isset($_POST['submit'])) {
    $name = $_POST['Student_Name'];
    $phoneNum = $_POST['StudentPhoneNumber'];
    $email = $_POST['Student_Address'];
    $password = $_POST['StudentPwd'];

    // Update student details if any change
    $updateDetailsResult = updateStudentDetails($conn, $studentID, $name, $phoneNum, $email);
    if ($updateDetailsResult === true) {
        // If student details updated successfully, check if password needs to be updated
        if (!empty($password)) {
            $updatePasswordResult = updateStudentPassword($conn, $studentID, $password);
            if ($updatePasswordResult === true) {
                $message = "Record updated successfully";
            } else {
                $message = $updatePasswordResult;
            }
        } else {
            $message = "Record updated successfully";
        }
        
        // Fetch updated student details
        $sql_fetch_student = "SELECT * FROM student WHERE Student_ID=?";
        $stmt_fetch_student = $conn->prepare($sql_fetch_student);
        $stmt_fetch_student->bind_param("i", $studentID);
        $stmt_fetch_student->execute();
        $result_fetch_student = $stmt_fetch_student->get_result();
        if ($result_fetch_student && $result_fetch_student->num_rows > 0) {
            $student = $result_fetch_student->fetch_assoc();
            $_SESSION['Student_ID'] = $studentID; // Update session with updated student ID
        }
    } else {
        $message = $updateDetailsResult;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="EditStudent.css">
    <title>Edit Personal Details</title>
</head>
<body>
    <div class="sidebar">
        <img src="gambar/profile picture.png" alt="Profile Picture" class="profile-picture">
        <h1>Welcome, <?php echo htmlspecialchars($student['Student_Name'] ?? 'Student'); ?></h1>
        <div class="sidebar_title">
            <a href="mainMenu.php">HOME</a>
            <a href="ProfileStudent.php">STUDENT PROFILE</a>
            <a href="editStudent.php">EDIT PROFILE</a>
            <a href="includes/logout.inc.php">LOG OUT</a>
        </div>
    </div>
    
    <div class="content">
        <h1>Edit Student Details</h1>
        <div class="box">
            <form action="editStudent.php" method="post">
                <div class="form-group">
                    <label for="Student_Name">Name:</label>
                    <input type="text" id="Student_Name" name="Student_Name" value="<?php echo htmlspecialchars($student['Student_Name']); ?>">
                </div>
                <div class="form-group">
                    <label for="StudentPhoneNumber">Phone Number:</label>
                    <input type="text" id="StudentPhoneNumber" name="StudentPhoneNumber" value="<?php echo htmlspecialchars($student['StudentPhoneNumber']); ?>">
                </div>
                <div class="form-group">
                    <label for="Student_Address">Email Address:</label>
                    <input type="email" id="Student_Address" name="Student_Address" value="<?php echo htmlspecialchars($student['Student_Address']); ?>">
                </div>
                <div class="form-group">
                    <label for="StudentPwd">New Password:</label>
                    <input type="password" id="StudentPwd" name="StudentPwd" placeholder="Leave blank to keep current">
                </div>
                <button type="submit" name="submit">Submit</button>
                <div id="update-message"><?php echo htmlspecialchars($message); ?></div>
            </form>
        </div>
    </div>
</body>
</html>
