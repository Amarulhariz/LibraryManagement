<?php 
    session_start();

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        // Include your database connection file
        include 'includes/dbh.inc.php';

        $bookCode = mysqli_real_escape_string($conn, $_POST['bookCode']);
        $bookGenre = mysqli_real_escape_string($conn, $_POST['bookGenre']);
        $bookName = mysqli_real_escape_string($conn, $_POST['bookName']);
        $bookAuthor = mysqli_real_escape_string($conn, $_POST['bookAuthor']);

        // SQL to insert new book
        $sql = "INSERT INTO books (Book_Code, Book_Genre, Book_Name, Book_Author) VALUES ('$bookCode', '$bookGenre', '$bookName', '$bookAuthor')";

        if (mysqli_query($conn, $sql)) {
            // Redirect to the next page with the book code
            header("Location: Add_PhysicalBook.php?bookCode=" . urlencode($bookCode));
            exit();
        } else {
            echo "<p style='color: red;'>Error: " . $sql . "<br>" . mysqli_error($conn) . "</p>";
        }

        // Close the database connection
        mysqli_close($conn);
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Book</title>
    <link rel="stylesheet" href="addbook.css">
    <link rel="stylesheet" href="SideBar.css">
</head>
<body>
    <div class="container">
        <h2>Add New Book</h2>
        <form id="addBookForm" action="" method="post">
            <div class="form-group">
                <label for="bookCode">Book Code</label>
                <input type="text" id="bookCode" name="bookCode" required>
            </div>
            <div class="form-group">
                <label for="bookGenre">Book Genre</label>
                <input type="text" id="bookGenre" name="bookGenre" required>
            </div>
            <div class="form-group">
                <label for="bookName">Book Name</label>
                <input type="text" id="bookName" name="bookName" required>
            </div>
            <div class="form-group">
                <label for="bookAuthor">Book Author</label>
                <input type="text" id="bookAuthor" name="bookAuthor" required>
            </div>
            <div class="form-group">
                <button type="submit">Add Book</button>
            </div>
        </form>
    </div>
    <div class="reference" onclick="toggleMenu()">
    <span></span>
    <span></span>
    <span></span>
</div>

<div id="sideMenu" class="sidebar">
    <button class="close-btn" onclick="toggleMenu()">&times;</button> <!-- Close Button -->
    <img src="gambar/MAHA1.png" alt="Profile Picture">
    <a href="mainMenu.php">Main Menu</a>
    <a href='AddBook.php'>Add new Book</a>
    <a href='UpdateDeleteBook.php'>Update and Delete new Book</a>
    <a href='GenerateRecord.php'>Print Borrowing Record</a>
</div>

<div class="overlay" onclick="toggleMenu()"></div>
<script>
function toggleMenu() {
    const reference = document.querySelector('.reference');
    const sidebar = document.getElementById('sideMenu');
    const overlay = document.getElementById('overlay');

    reference.classList.toggle('toggle');
    sidebar.classList.toggle('show');
    overlay.classList.toggle('show');
}

// Initialize the overlay click event
document.addEventListener('DOMContentLoaded', function () {
    const overlay = document.getElementById('overlay');
    overlay.addEventListener('click', toggleMenu);
});

</script>
<script src="script.js"></script>
</body>
</html>
