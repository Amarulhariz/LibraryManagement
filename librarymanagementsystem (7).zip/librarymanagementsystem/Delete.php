<?php
include 'header.php';
include 'includes/dbh.inc.php';

if (isset($_POST['delete'])) {
    if(isset($_POST['book_code'])) {
        foreach ($_POST['book_code'] as $bookCode) {
            // prevent SQL injection
            $bookCode = mysqli_real_escape_string($conn, $bookCode);

            // SQL query to delete the book
            $sql = "DELETE FROM books WHERE Book_Code = '$bookCode'" ;

            // Execute the query
            if (mysqli_query($conn, $sql)) {
                echo "Record deleted successfully";
            } else {
                echo "Error deleting record: " . mysqli_error($conn);
            }
        }
    }
    // Redirect back to the search page after deletion
    header("Location: updateDeleteBook.php");
    exit();
} else {
    echo "No book code received.";
}
?>
