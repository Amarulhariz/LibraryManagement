<?php
    // Include your database connection file
    include 'includes/dbh.inc.php';

    // Get the book code from the URL parameter
    $bookCode = isset($_GET['bookCode']) ? $_GET['bookCode'] : '';

    // Check if the book code is empty
    if (empty($bookCode)) {
        echo "<p style='color: red;'>Error: No book code provided. Please go back and try again.</p>";
        exit();
    }

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $bookCode = mysqli_real_escape_string($conn, $_POST['bookCode']);
        $ebookLink = mysqli_real_escape_string($conn, $_POST['ebookLink']);
        $ebookCodeStatus = mysqli_real_escape_string($conn, $_POST['ebookCodeStatus']);

        // SQL to insert new eBook
        $sql = "INSERT INTO ebook (Book_Code, Ebook_Link, EbookCode_Status) VALUES ('$bookCode', '$ebookLink', '$ebookCodeStatus')";

        if (mysqli_query($conn, $sql)) {
            echo "<script>
                    alert('eBook added successfully!');
                    window.location.href = 'AddBook.php';
                  </script>";
        } else {
            echo "<p style='color: red;'>Error: " . $sql . "<br>" . mysqli_error($conn) . "</p>";
        }

        // Close the database connection
        mysqli_close($conn);
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add eBook</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="SideBar.css">
    <link rel="stylesheet" href="addbook.css">
</head>
<body>
    <div class="container">
        <h2>Add eBook</h2>
        <form id="addEbookForm" action="" method="post">
            <div class="form-group">
                <label for="bookCode">Book Code</label>
                <input type="text" id="bookCode" name="bookCode" value="<?php echo htmlspecialchars($bookCode); ?>" required readonly>
            </div>
            <div class="form-group">
                <label for="ebookLink">eBook Link</label>
                <input type="text" id="ebookLink" name="ebookLink" required>
            </div>
            <div class="form-group">
                <label for="ebookCodeStatus">eBook Status</label>
                <input type="text" id="ebookCodeStatus" name="ebookCodeStatus" required>
            </div>
            <div class="form-group">
                <button type="submit">Add eBook</button>
            </div>
        </form>
    </div>
    <div class="reference" onclick="toggleMenu()">
        <span></span>
        <span></span>
        <span></span>
    </div>
    <div id="sideMenu" class="sidebar">
        <button class="close-btn" onclick="toggleMenu()">&times;</button>
        <img src="gambar/MAHA1.png" alt="Profile Picture">
        <a href="mainMenu.php">Main Menu</a>
        <a href="searchBook.php">Search Book</a>
        <a href="RequestPhysical.php">Request Physical Books</a>
    </div>
    <div class="overlay" onclick="toggleMenu()"></div>
    <script>
        function toggleMenu() {
            const reference = document.querySelector('.reference');
            const sidebar = document.getElementById('sideMenu');
            const overlay = document.getElementById('overlay');

            reference.classList.toggle('toggle');
            sidebar.classList.toggle('show');
            overlay.classList.toggle('show');
        }

        document.addEventListener('DOMContentLoaded', function () {
            const overlay = document.getElementById('overlay');
            overlay.addEventListener('click', toggleMenu);
        });
    </script>
    <script src="script.js"></script>
</body>
</html>
