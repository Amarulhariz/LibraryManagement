<?php
session_start();
include 'includes/dbh.inc.php'; // Include your database connection file

// basic sql
$sql = "SELECT r.Staff_ID, r.Student_ID, r.Book_Code, r.RequestedP_Status, r.PickUp_Date, r.PickUp_Time
        FROM requestp r";

// Execute the query
$result = mysqli_query($conn, $sql);

// Check if any results were found
$queryResult = mysqli_num_rows($result);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="ViewPhysical.css">
    <link rel="stylesheet" href="SideBar.css">
    <title>Search Page</title>
    <style>
        /* Add any additional CSS styles here */
    </style>
</head>
<body>

<?php if ($queryResult > 0) { ?>

    <div class="container">
        <h1>View Request Physical Books</h1>
        <table>
            <tr>
                <th>Student ID</th>
                <th>Staff ID</th>
                <th>Book Code</th>
                <th>Request Status</th>
                <th>Pick Up Date</th>
                <th>Pick Up Time</th>
            </tr>

            <?php while ($row = mysqli_fetch_assoc($result)) { ?>
    <tr>
        <td><?php echo htmlspecialchars($row['Student_ID']); ?></td>
        <td><?php echo isset($row['Staff_ID']) ? htmlspecialchars($row['Staff_ID']) : '-'; ?></td>
        <td><?php echo htmlspecialchars($row['Book_Code']); ?></td>
        <td><?php echo htmlspecialchars($row['RequestedP_Status']); ?></td>
        <td><?php echo htmlspecialchars($row['PickUp_Date']); ?></td>
        <td><?php echo htmlspecialchars($row['PickUp_Time']); ?></td>
    </tr>
<?php } ?>


        </table>
    </div>

<?php } else { ?>
    
    <div class="container">
        No Requested Book
    </div>

<?php } ?>

<?php include 'footer.php'; ?>

<div class="reference" onclick="toggleMenu()">
    <span></span>
    <span></span>
    <span></span>
</div>

<div id="sideMenu" class="sidebar">
    <button class="close-btn" onclick="toggleMenu()">&times;</button> <!-- Close Button -->
    <img src="gambar/MAHA1.png" alt="Profile Picture">
    <a href="mainMenu.php">Main Menu</a>
    <a href="searchBook.php">Search Book</a>
    <a href="RequestPhysical.php">Request Physical Books</a>
    <a href='RequestEbook.php'>Request EBook</a>
    <a href='viewRequestPhysical.php'>View Request Physical Books</a>
    <a href='viewRequestEbook.php'>View Request EBooks</a>
</div>

<div class="overlay" onclick="toggleMenu()"></div>

<script>
function toggleMenu() {
    const reference = document.querySelector('.reference');
    const sidebar = document.getElementById('sideMenu');
    const overlay = document.querySelector('.overlay');

    reference.classList.toggle('toggle');
    sidebar.classList.toggle('show');
    overlay.classList.toggle('show');
}

// Initialize the overlay click event
document.addEventListener('DOMContentLoaded', function () {
    const overlay = document.querySelector('.overlay');
    overlay.addEventListener('click', toggleMenu);
});
</script>

<script src="script.js"></script>

</body>
</html>
