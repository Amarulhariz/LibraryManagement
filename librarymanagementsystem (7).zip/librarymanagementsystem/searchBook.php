<?php
    session_start();
?>
<?php
    include_once 'includes/dbh.inc.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MAHA Library</title>
    <link rel="stylesheet" href="searchBook.css">
    <link rel="stylesheet" href="SideBar.css">
</head>
<body>
    <div class="box">
        <div class="header">
            <h1>MAHA LIBRARY</h1>
            <p>"HERE WHERE THE SEED OF KNOWLEDGE GROW"</p>
        </div>
        <div class="search-container">
            <form action="SAfterSearch.php" method="POST">
                <input type="text" name="bookNameS" placeholder="Search Book">
                <button type="submit" name="bookName"><i class="fa fa-search"></i> Search</button>
            </form>
        </div>
        <div class="genre-container">
            <h2>CHOOSE YOUR FAVOURITE BOOK GENRE</h2>
            <div class="genre">
                <img src="gambar/fiction-category.png" alt="Fiction">
                <a href="BookType/Fiction.php">Fiction</a>
            </div>
            <div class="genre">
                <img src="gambar/romance-category.png" alt="Romance">
                <a href="BookType/Romance.php">Romance</a>
            </div>
            <div class="genre">
                <img src="gambar/mystery.png" alt="Mystery">
                <a href="BookType/Mystery.php">Mystery</a>
            </div>
            <div class="genre">
                <img src="gambar/education-category.png" alt="Education">
                <a href="BookType/Education.php">Education</a>
            </div>
            <div class="genre">
                <img src="gambar/horror.png" alt="Horror">
                <a href="BookType/Horror.php">Horror</a>
            </div>
            <div class="genre">
                <img src="gambar/adventure-category.png" alt="Adventure">
                <a href="BookType/Adventure.php">Adventure</a>
            </div>
        </div>
    </div>
    <div class="reference" onclick="toggleMenu()">
    <span></span>
    <span></span>
    <span></span>
</div>

<div id="sideMenu" class="sidebar">
    <button class="close-btn" onclick="toggleMenu()">&times;</button> <!-- Close Button -->
    <img src="gambar/MAHA1.png" alt="Profile Picture">
    <a href="mainMenu.php">Main Menu</a>
    <a href="searchBook.php">Search Book</a>
    <a href="RequestPhysical.php">Request Physical Books</a>
    <a href='RequestPhysical.php'>Request Physical Book</a>
    <a href='RequestEbook.php'>Request EBook</a>
    <a href='viewRequestPhysical.php'>View Request Physical Books</a>
    <a href='viewRequestEbook.php'>View Request EBooks</a>
</div>

<div class="overlay" onclick="toggleMenu()"></div>
<script>
function toggleMenu() {
    const reference = document.querySelector('.reference');
    const sidebar = document.getElementById('sideMenu');
    const overlay = document.getElementById('overlay');

    reference.classList.toggle('toggle');
    sidebar.classList.toggle('show');
    overlay.classList.toggle('show');
}

// Initialize the overlay click event
document.addEventListener('DOMContentLoaded', function () {
    const overlay = document.getElementById('overlay');
    overlay.addEventListener('click', toggleMenu);
});

</script>
<script src="script.js"></script>
</body>
</html>

<?php
    include_once 'footer.php';
?>
