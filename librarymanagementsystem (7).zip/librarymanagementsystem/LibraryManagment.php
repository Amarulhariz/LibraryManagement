.login-button {
			background-color: #6e3434;
			color: #fefefe;
			padding: 5px 60px;
			border: none;
			border-radius: 30px;
			cursor: pointer;
			border: 2px solid #000000;
		}

        <script>
		function toggleMenu() {
			var menu = document.getElementById("sideMenu");
			var button = document.querySelector(".reference");
			
			if (menu.classList.contains("active")) {
				menu.classList.remove("active");
				button.classList.remove("toggle");
			} else {
				menu.classList.add("active");
				button.classList.add("toggle");
			}
		}
	</script>
	<div class="reference" onclick="toggleMenu()">
		<span></span>
		<span></span>
		<span></span>
	</div>
	<div id="sideMenu" class="side-menu">
	
	</div>

    .reference {
    position: absolute;
    top: 20px; /* Adjust as needed */
    left: 20px; /* Adjust as needed */
    z-index: 9999; /* Ensure it's above other content */
    cursor: pointer;
}

.reference span {
    display: block;
    width: 25px;
    height: 3px;
    background-color: rgb(255, 255, 255); /* Adjust color as needed */
    margin-bottom: 5px;
    transition: 0.4s;
}

.side-menu {
    height: 100%;
    width: 250px;
    position: fixed;
    top: 0;
    left: -250px;
    background-color: #000000;
    overflow-x: hidden;
    transition: 0.5s;
    z-index: 9998;
}

.side-menu a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 25px;
    color: white;
    display: block;
    transition: 0.3s;
}

.side-menu a:hover {
    background-color: #575757;
}

.side-menu.active {
    left: 0;
}

.reference.toggle span:nth-child(1) {
    transform: rotate(-45deg) translate(-5px, 6px);
}

.reference.toggle span:nth-child(2) {
    opacity: 0;
}

.reference.toggle span:nth-child(3) {
    transform: rotate(45deg) translate(-5px, -6px);
}