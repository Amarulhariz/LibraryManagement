<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="ViewEbook.css">
    <link rel="stylesheet" href="SideBar.css">
    <title>Search Page</title>
</head>
<body>
    <?php
    session_start();
    include 'includes/dbh.inc.php'; // Include your database connection file
    if (isset($_SESSION["Student_ID"])) {
        $student = $_SESSION["Student_ID"];
    }
    // basic sql
    $sql = "SELECT r.Staff_ID, r.Student_ID, r.Book_Code, r.EBook_Link, r.Requested_Status
            FROM request r";

    // Execute the query
    $result = mysqli_query($conn, $sql);
    // Check if any results were found
    $queryResult = mysqli_num_rows($result);

    if ($queryResult > 0) {
        // Output the results in a table
        echo '<div class="container">';
        echo '<h1>View Reqeust E-Book</h1>';
        echo '<table>';
        echo '<tr><th>Student ID</th><th>Staff ID</th><th>Book Code</th><th>E-Book Link</th><th>Status</th></tr>';

        // Loop through each row in the result set and display the data
        while($row = mysqli_fetch_assoc($result)) 
        {
            echo '<tr>';
            echo "<td>" . $row["Student_ID"] . "</td>";
            echo isset($row["Staff_ID"]) ? "<td>" . $row["Staff_ID"] . "</td>" : "<td>-</td>";
            echo "<td>" . $row["Book_Code"] . "</td>";
            echo "<td>" . $row["EBook_Link"] . "</td>";
            echo "<td>" . $row["Requested_Status"] . "</td>";
            echo '</tr>';
        }

        echo '</table>';
        echo '</div>';
    } else {
        echo "<div class='container'>";
        echo "No Requested Book";
        echo "</div>";
    }

    ?>
    
    <?php include 'footer.php'; ?>
    <div class="reference" onclick="toggleMenu()">
    <span></span>
    <span></span>
    <span></span>
</div>

<div id="sideMenu" class="sidebar">
    <button class="close-btn" onclick="toggleMenu()">&times;</button> <!-- Close Button -->
    <img src="gambar/MAHA1.png" alt="Profile Picture">
    <a href="mainMenu.php">Main Menu</a>
    <a href="searchBook.php">Search Book</a>
    <a href="RequestPhysical.php">Request Physical Books</a>
    <a href='RequestEbook.php'>Request EBook</a>
    <a href='viewRequestPhysical.php'>View Request Physical Books</a>
    <a href='viewRequestEbook.php'>View Request EBooks</a>
</div>

<div class="overlay" onclick="toggleMenu()"></div>
<script>
function toggleMenu() {
    const reference = document.querySelector('.reference');
    const sidebar = document.getElementById('sideMenu');
    const overlay = document.getElementById('overlay');

    reference.classList.toggle('toggle');
    sidebar.classList.toggle('show');
    overlay.classList.toggle('show');
}

// Initialize the overlay click event
document.addEventListener('DOMContentLoaded', function () {
    const overlay = document.getElementById('overlay');
    overlay.addEventListener('click', toggleMenu);
});

</script>
<script src="script.js"></script>
</body>
</html>
